# Duplicate Tasks Miner (DTM)

This repository contains the source code of **Duplicate Tasks Miner (DTM)** and supplementary materials for the runtime and robustness evaluations. DTM discovers process models from event logs containing duplicate tasks by analyzing contextual relations, refining task labels through a transition system, and applying Inductive Miner.

## Repository contents

```text
Dup/
├── README.md
├── code/
│   └── ShandongPM/        Eclipse/ProM plugin project
├── NoiseExperiment/
│   ├── logs/             111 input event logs in XES format
│   ├── models/           111 discovered models in PNML format
│   └── result/           Per-run results, summaries, and log manifest
└── TimeExperiment/       18 runtime comparison figures (a.png–r.png)
```

## Source code

The plugin is displayed in ProM as **Duplicate Tasks Miner Plugin**. Its entry point is [`MineDuplicateTasksFixedConfigTrial.java`](code/ShandongPM/src/MingPetriNetUsingTransitionsystemToProcessTree/MineDuplicateTasksFixedConfigTrial.java).

The source directory contains seven Java files:

| File | Purpose |
| --- | --- |
| `MineDuplicateTasksFixedConfigTrial.java` | Plugin entry, mining options, transition-system configuration, and model discovery. |
| `DuplicateTasks.java` | Identification of candidate duplicate-task labels from contextual relations. |
| `ParallelContextRepair.java` | Repair of relations involving parallel contexts. |
| `InductiveMinerPlugin.java` | Log-based IM discovery and conversion/post-processing utilities. |
| `InductiveMinerWithoutLogPlugin.java` | Discovery from the constructed directly-follows graph. |
| `InductiveMinerWithoutLogDialog.java` | Dialog type referenced by the discovery helper. |
| `duplicateTasks/GetVariantLog.java` | Extraction of trace variants. |

The first six files are in the `MingPetriNetUsingTransitionsystemToProcessTree` package. The final file is in the `duplicateTasks` package.

### Running the plugin

1. Use a Java 8-compatible development environment and a compatible ProM installation.
2. Import [`code/ShandongPM`](code/ShandongPM) into Eclipse as an existing project.
3. Resolve the ProM dependencies through the supplied Ivy configuration and the installed ProM libraries. Update machine-specific paths in `.classpath` and launch settings where necessary. Dependencies include Inductive Miner, Transition Systems, Petri Nets, Accepting Petri Net, OpenXES, and the ProM framework/UI libraries.
4. Build the project and start ProM using the supplied launch configuration after adapting it to the local installation.
5. Import an XES event log, select **Duplicate Tasks Miner Plugin**, and choose the mining mode. The plugin returns a Petri net.

The implementation exposes options with and without noise filtering. The robustness results distributed below use only the **unfiltered configuration (`dtm0`)**. Optional filtering should not be interpreted as a demonstrated robustness guarantee.

## Noise and incomplete-log evaluation

The evaluation uses three datasets: **flightCar**, **bingxuan**, and **INloop**. Each clean baseline contains 300 traces while retaining all observed variants.

- **Event noise:** deletion, insertion, or swapping of internal events in 5%, 10%, or 20% of traces, with at most one edit per selected trace. First and last events are preserved. These percentages refer to selected traces, not the proportion of all events edited.
- **Incomplete logs:** retain subsets of variants at requested coverage levels of 25%, 50%, or 75%, then resample to 300 traces. Actual coverage can differ because the number of retained variants must be an integer.
- **Random seeds:** `20261028`, `20261029`, and `20261030` for each perturbed condition.

The collection contains **3 clean baselines, 81 noisy logs, and 27 incomplete logs**, with one unfiltered DTM result and one discovered model for every input.

### Result files

| File | Contents |
| --- | --- |
| [`summary.csv`](NoiseExperiment/result/summary.csv) | Overall results for clean, noisy, and incomplete conditions. |
| [`summary_by_dataset.csv`](NoiseExperiment/result/summary_by_dataset.csv) | Results grouped by dataset and condition category. |
| [`summary_by_condition.csv`](NoiseExperiment/result/summary_by_condition.csv) | Results grouped by dataset, operation, and requested level. |
| [`results.csv`](NoiseExperiment/result/results.csv) | All 111 selected runs, including model generation, acceptance, equivalence, model size, and recorded mining time. |
| [`log_manifest.csv`](NoiseExperiment/result/log_manifest.csv) | Log identifiers, parameters, trace/variant counts, actual perturbation or coverage, and SHA-256 hashes. |

### Overall findings

| Condition | Models generated | Mean clean-trace acceptance | Reference-language equivalence |
| --- | ---: | ---: | ---: |
| Clean | 3/3 | 100.0% | 3/3 |
| Noisy | 81/81 | 95.1% | 0/81 |
| Incomplete | 27/27 | 64.3% | 7/27 |

Clean-trace acceptance measures whether complete traces from the clean baseline can execute from the initial marking to a final marking. Each run is weighted by baseline trace frequencies; the reported overall value is the arithmetic mean across runs. **This metric is not alignment-based fitness.** Reference-language equivalence compares complete visible execution languages. Generating a model or obtaining high clean-trace acceptance does not establish recovery of the reference behavior. These findings are limited to the evaluated datasets and perturbations.

### Matching logs and models

For example:

```text
NoiseExperiment/logs/flightCar_insert_r10_s20261028.xes
NoiseExperiment/models/flightCar_insert_r10_s20261028__dtm0.pnml
```

Here, `r10` denotes a requested 10% trace-editing rate and `s20261028` identifies the seed. For incomplete logs, `c25`, `c50`, and `c75` denote requested variant coverage. Use the manifest for actual values.

In the CSV files, log and model paths are relative to `NoiseExperiment/`, rather than its `result/` subdirectory. Some other path columns retain locations from the original experiment package: the referenced `runs/` and `reference-models/` directories are not included in this repository. The distributed noise materials comprise the input logs, discovered models, and result CSVs listed above.

## Runtime evaluation

[`TimeExperiment/`](TimeExperiment) contains 18 box-plot figures, named `a.png` through `r.png`, for the runtime comparisons. Times are reported in **milliseconds**. Read each figure using its own method labels and axis scale; some figures contain broken axes.

| Figures | Figures | Figures |
| --- | --- | --- |
| [a](TimeExperiment/a.png) | [b](TimeExperiment/b.png) | [c](TimeExperiment/c.png) |
| [d](TimeExperiment/d.png) | [e](TimeExperiment/e.png) | [f](TimeExperiment/f.png) |
| [g](TimeExperiment/g.png) | [h](TimeExperiment/h.png) | [i](TimeExperiment/i.png) |
| [j](TimeExperiment/j.png) | [k](TimeExperiment/k.png) | [l](TimeExperiment/l.png) |
| [m](TimeExperiment/m.png) | [n](TimeExperiment/n.png) | [o](TimeExperiment/o.png) |
| [p](TimeExperiment/p.png) | [q](TimeExperiment/q.png) | [r](TimeExperiment/r.png) |

The runtime directory currently provides figures rather than raw repeated-run measurements. Separately, `mining_ms` in the noise experiment CSV records diagnostic mining time. Those noise-experiment timings were collected with a fixed configuration order in the original execution and should not be treated as the paper's cross-method runtime benchmark.
