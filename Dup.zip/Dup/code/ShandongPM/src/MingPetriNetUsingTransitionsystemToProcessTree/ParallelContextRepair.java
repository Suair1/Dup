package MingPetriNetUsingTransitionsystemToProcessTree;

import java.util.*;
import org.deckfour.xes.model.*;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.processmining.models.graphbased.directed.transitionsystem.Transition;

/** Conservative repair for a fully observed, adjacent two-activity interleaving block. */
public final class ParallelContextRepair {
    private ParallelContextRepair() {}

    public static HashMap<Transition, Transition> repair(HashMap<Transition, Transition> relations, XLog log) {
        Set<List<String>> variants = new HashSet<List<String>>();
        for (XTrace trace : log) {
            List<String> names = new ArrayList<String>();
            for (XEvent event : trace) { names.add(XConceptExtension.instance().extractName(event)); }
            variants.add(names);
        }
        Set<List<String>> rules = new HashSet<List<String>>();
        for (List<String> trace : variants) {
            for (int i = 1; i + 2 < trace.size(); i++) {
                String p = trace.get(i - 1), a = trace.get(i), b = trace.get(i + 1), q = trace.get(i + 2);
                if (new HashSet<String>(Arrays.asList(p, a, b, q)).size() != 4) { continue; }
                List<String> swapped = new ArrayList<String>(trace);
                Collections.swap(swapped, i, i + 1);
                if (variants.contains(swapped)) {
                    List<String> pair = new ArrayList<String>(Arrays.asList(a, b));
                    Collections.sort(pair);
                    rules.add(Arrays.asList(p, pair.get(0), pair.get(1), q));
                }
            }
        }
        List<List<String>> orderedRules = new ArrayList<List<String>>(rules);
        Collections.sort(orderedRules, new Comparator<List<String>>() {
            public int compare(List<String> a, List<String> b) {
                for (int i = 0; i < a.size(); i++) { int c = a.get(i).compareTo(b.get(i)); if (c != 0) { return c; } }
                return 0;
            }
        });
        HashMap<Transition, Transition> current = relations;
        for (List<String> rule : orderedRules) {
            String p = rule.get(0), a = rule.get(1), b = rule.get(2), q = rule.get(3);
            if (!allBoundaryOccurrencesMatch(variants, p, a, b, q)) { continue; }
            Map<String, Set<String>> next = new HashMap<String, Set<String>>();
            Map<String, Set<String>> previous = new HashMap<String, Set<String>>();
            for (Map.Entry<Transition, Transition> edge : current.entrySet()) {
                String source = edge.getKey().getLabel(), target = edge.getValue().getLabel();
                if (!next.containsKey(source)) { next.put(source, new HashSet<String>()); }
                next.get(source).add(target);
                if (!previous.containsKey(target)) { previous.put(target, new HashSet<String>()); }
                previous.get(target).add(source);
            }
            Set<String> aLabels = new HashSet<String>(), bLabels = new HashSet<String>();
            boolean ab = false, ba = false;
            for (String open : next.keySet()) {
                if (!base(open).equals(p)) { continue; }
                for (String first : next.get(open)) {
                    if (!base(first).equals(a) && !base(first).equals(b)) { continue; }
                    for (String second : next.getOrDefault(first, Collections.<String>emptySet())) {
                        if (base(first).equals(base(second))) { continue; }
                        if (!base(second).equals(a) && !base(second).equals(b)) { continue; }
                        for (String close : next.getOrDefault(second, Collections.<String>emptySet())) {
                            if (!base(close).equals(q)) { continue; }
                            (base(first).equals(a) ? aLabels : bLabels).add(first);
                            (base(second).equals(a) ? aLabels : bLabels).add(second);
                            if (base(first).equals(a)) { ab = true; } else { ba = true; }
                        }
                    }
                }
            }
            if (!ab || !ba || !localOnly(aLabels, p, b, q, previous, next)
                    || !localOnly(bLabels, p, a, q, previous, next)) { continue; }
            Map<String, String> rename = new HashMap<String, String>();
            mergeLabels(aLabels, rename); mergeLabels(bLabels, rename);
            Set<String> all = new HashSet<String>(next.keySet()); all.addAll(previous.keySet());
            for (String label : all) {
                if (base(label).equals(p)) { rename.put(label, p + "+complete"); }
                if (base(label).equals(q)) { rename.put(label, q + "+complete"); }
            }
            HashMap<Transition, Transition> changed = new HashMap<Transition, Transition>();
            for (Map.Entry<Transition, Transition> edge : current.entrySet()) {
                Transition source = edge.getKey(), target = edge.getValue();
                Transition s = new Transition(source.getSource(), source.getTarget(), new Object());
                Transition t = new Transition(target.getSource(), target.getTarget(), new Object());
                s.setLabel(rename.getOrDefault(source.getLabel(), source.getLabel()));
                t.setLabel(rename.getOrDefault(target.getLabel(), target.getLabel()));
                changed.put(s, t);
            }
            current = changed;
            System.out.println("Confirmed adjacent interleaving block: " + rule);
        }
        return current;
    }

    private static boolean allBoundaryOccurrencesMatch(Set<List<String>> variants, String p, String a, String b, String q) {
        for (List<String> trace : variants) {
            if (Collections.frequency(trace, p) > 1 || Collections.frequency(trace, q) > 1) { return false; }
            for (int i = 0; i < trace.size(); i++) {
                if (trace.get(i).equals(p)) {
                    if (i + 3 >= trace.size() || !trace.get(i + 3).equals(q)
                            || !isPair(trace.get(i + 1), trace.get(i + 2), a, b)) { return false; }
                }
                if (trace.get(i).equals(q)) {
                    if (i < 3 || !trace.get(i - 3).equals(p)
                            || !isPair(trace.get(i - 2), trace.get(i - 1), a, b)) { return false; }
                }
            }
        }
        return true;
    }
    private static boolean isPair(String x, String y, String a, String b) {
        return (x.equals(a) && y.equals(b)) || (x.equals(b) && y.equals(a));
    }
    private static boolean localOnly(Set<String> labels, String p, String other, String q,
            Map<String, Set<String>> previous, Map<String, Set<String>> next) {
        for (String label : labels) {
            for (String before : previous.getOrDefault(label, Collections.<String>emptySet())) {
                if (!base(before).equals(p) && !base(before).equals(other)) { return false; }
            }
            for (String after : next.getOrDefault(label, Collections.<String>emptySet())) {
                if (!base(after).equals(q) && !base(after).equals(other)) { return false; }
            }
        }
        return true;
    }
    private static void mergeLabels(Set<String> labels, Map<String, String> rename) {
        String canonical = Collections.min(labels);
        for (String label : labels) { rename.put(label, canonical); }
    }
    private static String base(String label) {
        return label.replace("+complete", "").replaceFirst(":[0-9]+$", "");
    }
}
