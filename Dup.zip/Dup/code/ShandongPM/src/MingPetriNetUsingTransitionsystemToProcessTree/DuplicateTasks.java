
package MingPetriNetUsingTransitionsystemToProcessTree;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;

import duplicateTasks.GetVariantLog;

public class DuplicateTasks {
	@Plugin(
			name = "1111111111Duplicate Tasks Candidates Miner11111",// plugin name
			returnLabels = {"HashSet<String>" }, //return labels
			returnTypes = {HashSet.class},//return class
			parameterLabels = {"Event Log"},
			userAccessible = true,
			help = "This plugin aims to discover duplicate tasks candidates from an event log with duplicate tasks." 
			)
	@UITopiaVariant(
	        affiliation = "SDUT", 
	        author = "Xuan Su", 
	        email = "15715325632@163.com"
	        )
	@PluginVariant(
			variantLabel = "Mining Event Log with Duplicate Tasks, default",
			requiredParameterLabels = {0}
			)
	public static HashSet<String> DuplicateTasksMining(UIPluginContext context,XLog originalLog) 
	{

		//step1    �õ�������־
		XLog VariantLog = GetVariantLog.SimRankSamplingTechnique(originalLog);
//		//convert Log to DFG 
//		Dfg dfg = XLog2Dfg.log2Dfg(context, VariantLog);
		
		
		
		
		
		
		
//		 //ת��Ϊ��Ǩϵͳ
//        XEventClassifier[] classifiers = new XEventClassifier[3];
//        classifiers[0] = new XEventNameClassifier();
//        classifiers[1] = new XEventResourceClassifier();
//        classifiers[2] = new XEventLifeTransClassifier();
//        XEventClassifier transitionClassifier = new XEventAndClassifier(new XEventNameClassifier(),new XEventLifeTransClassifier());
//     
//        TSMinerUI miner= new TSMinerUI(context);
//     
//		
//        Object[] objects= miner.mine(VariantLog, Arrays.asList(classifiers), transitionClassifier); 
//        TransitionSystem result=(TransitionSystem) objects[0];
		
		
		
		
		
		
		
		
		
		//step2   ��ȡ���л�����ѡ�ظ���������
		//���к�ѡ�����
		HashSet<String> CandidateActivitySet = new HashSet<>();
		//trace to direct-follow relation set�켣��ֱ�Ӹ����ϵ���ϼ���
		HashSet<String> AllDFRSet = new HashSet<>();//����ֱ�Ӹ�����ϵ����
		HashSet<String> dfrSet = new HashSet<>();
		int tracenumber = 0;
		Map<String, Integer> event2number = new HashMap<>();
		for(XTrace trace:VariantLog)
		{   tracenumber+=1;
		   // int includetrace =0;
			HashSet<String> activitySet = new HashSet<>();
			
			for(int i=0;i<=trace.size()-1;i++)
			{
				//add activity 
				activitySet.add(XConceptExtension.instance().extractName(trace.get(i)));
				CandidateActivitySet.add(XConceptExtension.instance().extractName(trace.get(i)).toString());
				if(event2number.keySet().contains(XConceptExtension.instance().extractName(trace.get(i)).toString())) {
					event2number.put(XConceptExtension.instance().extractName(trace.get(i)).toString(), event2number.get(XConceptExtension.instance().extractName(trace.get(i)).toString())+1);
				}
				else {
					event2number.put(XConceptExtension.instance().extractName(trace.get(i)).toString(), 1);
				}
			}
			for (int i = 0; i < trace.size() - 1; i++) {
				//add directly follow pair
				dfrSet.add(XConceptExtension.instance().extractName(trace.get(i)) + ","
						+ XConceptExtension.instance().extractName(trace.get(i + 1)));
			}
//			AllDFRSet.add(dfrSet); 
		}
		System.out.println("CandidateActivitySet========>"+CandidateActivitySet);
		System.out.println("dfrSet========>"+dfrSet);
//		System.out.println("traceIDToDFRSet========>"+traceIDToDFRSet);
		
		
		//step3  ͳ��ÿ�����ǰ��Forerunner�����Successor��<ǰ�������>��ϵ��
		//�ǰ�����ϣ�PreSet   key:activity   value:precision
		Map<String,Set<String>> PreMap = new HashMap<>();
		//���̼��ϣ�SuccSet    key:activity   value:successor
		Map<String, Set<String>> SuccMap = new HashMap<>();
		//�������ǰ����̹�ϵ�Լ��� key:activity   value:dfrSet
		Map<String, Set<String>> RelationMap = new HashMap<>();
		

		  // ��ÿ���ַ����еĵ��ʷָ�洢��һ��List��
        List<List<String>> AllActivityList = new ArrayList<>();
        for (XTrace trace:VariantLog) {
        	List<String> ActivityList = new ArrayList<>();
        	for(int i=0;i<=trace.size()-1;i++)
			{
                ActivityList.add(XConceptExtension.instance().extractName(trace.get(i)).toString());
               // System.out.println(" &&&&&&&ActivityList========>"+ActivityList);
			}
        	AllActivityList.add(ActivityList);
        }
        System.out.println(" &&&&&&& AllActivityList========>"+ AllActivityList);
        // ����ǰ���ͺ�̼���
        for (List<String> words : AllActivityList) {
            for (int i = 0; i < words.size(); i++) {
                String word = words.get(i);
                //getOrDefault(key, default)�������key, �򷵻����Ӧ��value, ���򷵻ظ�����Ĭ��ֵ
                Set<String> preSet = PreMap.getOrDefault(word, new HashSet<>());
                Set<String> succSet = SuccMap.getOrDefault(word, new HashSet<>());
                Set<String> PairsSet = RelationMap.getOrDefault(word, new HashSet<>());
                if(i==0) { // ����ǰ��
                	preSet.add("null");
                    PreMap.put(word, preSet);
                    String relationPair = "null"+","+words.get(i+1);
                    PairsSet.add(relationPair);
                    RelationMap.put(word, PairsSet);
                }
                if (i > 0) {
                    String preWord = words.get(i-1);
                    preSet.add(preWord);
                    PreMap.put(word, preSet);
                }
                if (i < words.size()-1) { // ���Ӻ��
                    String succWord = words.get(i+1);
                    succSet.add(succWord);
                    SuccMap.put(word, succSet);
                }
                if(i==words.size()-1) {
                	succSet.add("null");
                    SuccMap.put(word, succSet);
                    String relationPair = words.get(i-1)+","+"null";
                    PairsSet.add(relationPair);
                    RelationMap.put(word, PairsSet);
                    
                }
                if(i>0 && i < words.size()-1) {//����ǰ����̹�ϵ��
                	String relationPair = words.get(i-1)+","+words.get(i+1);
                    PairsSet.add(relationPair);
                    RelationMap.put(word, PairsSet);
                }
            }
        }
		Map<String,Integer> PreNum = new HashMap<>(); 
		Map<String,Integer> SuccNum = new HashMap<>();
		Map<String,Integer> PairsNum = new HashMap<>();
		for (String word : PreMap.keySet()) {
			PreNum.put(word, PreMap.get(word).size());
			SuccNum.put(word, SuccMap.get(word).size());
			PairsNum.put(word, RelationMap.get(word).size());
			
        }
		
        System.out.println("PreNum------>" + PreNum);
        System.out.println("SuccNum------>" + SuccNum);
        System.out.println("PairsNum------>" + PairsNum);
        System.out.println(PreMap + "<-----PreMap+succSet------>" + SuccMap);
        System.out.println("RelationMap------>" + RelationMap);
        for (String word : PreMap.keySet()) {
            Set<String> preSet = PreMap.get(word);
            Set<String> succSet = SuccMap.get(word);
            Set<String> PairsSet = RelationMap.get(word);
            System.out.println("Activity��"+word + "��ǰ������Ϊ��" + preSet);
            System.out.println("Activity��"+word + "�ĺ�̼���Ϊ��" + succSet);
            System.out.println("Activity��"+word + "��ǰ����̹�ϵ��Ϊ��" + PairsSet);
        }
       
        HashSet<String> deleteactivity = new HashSet<>();
        for (String word : CandidateActivitySet) {
        	System.out.println("word:======>"+word);
        	//1.ǰ�������Ϊ1||ǰ������ҽ���1���ռ�
            if((PreNum.get(word)==1&&SuccNum.get(word)==1)||(PreMap.get(word).contains("null")&&PreNum.get(word)==1)||(SuccMap.get(word).contains("null")&&SuccNum.get(word)==1)) {
            	deleteactivity.add(word);
            	System.out.println("1-deleteactivity:======>"+deleteactivity);
            }
            //2.ǰ���Ϊ2&&��ϵ��Ϊ4
            if(PreNum.get(word)==2&&SuccNum.get(word)==2&&PairsNum.get(word)==4) {
            	HashSet<String> looplist = new HashSet<>();
            	looplist.addAll(PreMap.get(word));
            	looplist.addAll(SuccMap.get(word));
            	//2.1ǰ��֮��Ϊ3
            	if(looplist.size()==3) {
            		deleteactivity.add(word);
            		System.out.println("loop-deleteactivity:======>"+deleteactivity);
            	}
            	System.out.println("looplist:"+looplist);
            	//2.2ǰ��֮��Ϊ4
            	if(looplist.size()==4) {
            		System.out.println("@@@@@@@@@looplist.size()==4==@@@@@@@@@");
            		for (String preactivity : PreMap.get(word)) {
            			System.out.println("preactivity:======>"+preactivity);
            			for (String succactivity : SuccMap.get(word)) {
            				System.out.println("succactivity:======>"+succactivity);
            				System.out.println("PreMap.get(preactivity)****"+PreMap.get(preactivity));
            				for(String a: PreMap.get(preactivity)) {
            					if(a==succactivity)
            					System.out.println("a==succactivity:word:"+word);
            					deleteactivity.add(word);
            				}
            				for(String b: SuccMap.get(preactivity)) {
            					if(b==succactivity)
            					System.out.println("b==succactivity:word:"+word);
            					deleteactivity.add(word);
            				}
            			}
            		}
            	}
            }
        }
    	CandidateActivitySet.removeAll(deleteactivity);
    	deleteactivity.clear();
        System.out.println("��ǰ��һ��ɸѡCandidateActivitySetΪ��" + CandidateActivitySet);  
       
        //�洢�����ṹ�еķ��ظ�����
        Set<String> parallelNoDupSet = new HashSet<>();
        for (String word1 : CandidateActivitySet) {
			System.out.println("word1*******"+word1);
            //3.ǰ���������ȣ���ϵ�Ը���Ϊǰ�������Ľ׳ˣ�
        	System.out.println("PairsNum.get(word1)======>"+PairsNum.get(word1)+"::::::PreNum.get(word1)*(PreNum.get(word1)-1)))=======>" + PreNum.get(word1)*(PreNum.get(word1)-1));
            if((PreNum.get(word1)==SuccNum.get(word1))&&(PairsNum.get(word1)==(PreNum.get(word1)*(PreNum.get(word1)-1)))) {
            	System.out.println("����ڶ���ɸѡ��������" );
            	HashSet<String> pre2succlist = new HashSet<>();
            	pre2succlist.addAll(PreMap.get(word1));
            	pre2succlist.addAll(SuccMap.get(word1));
            	System.out.println("pre2succlist===>"+pre2succlist+"::size::"+pre2succlist.size());
            	if(PreMap.get(word1).equals(SuccMap.get(word1))) {
        			deleteactivity.add(word1);
        			parallelNoDupSet.add(word1);
        			System.out.println("���ڲ����ṹ�еķ��ظ����񣬲����ṹǰ���Ϊ�ظ�����");
        		}
            	//ǰ�ͺ�����֮��Ϊǰ��������1��
            	if(pre2succlist.size()==(PreNum.get(word1)+1)) {
            		System.out.println("pre2succlist.size()==(PreNum.get(word1)+1)=====pre2succlist.size():::"+pre2succlist.size()+"==========(PreNum.get(word1)+1):::"+PreNum.get(word1)+1);
            		if(PreNum.get(word1)==2) {
            			System.out.println("PreNum.get(word1)==2@@@@#####$$$$$$");
            			//���ڴ�Ž������
            			HashSet<String> resSet = new HashSet<>();
            			resSet.addAll(PreMap.get(word1));
            			resSet.retainAll(SuccMap.get(word1));
            			System.out.println("resSet===>"+resSet);
            			if(resSet.size()==1) {
            				if(resSet.iterator().next()!=word1) {
            					Set<String> parallelpairsSet = new HashSet<>();
            					parallelpairsSet = RelationMap.get(word1);
            					System.out.println("parallelpairsSet@@@@@@@~```````"+parallelpairsSet);
            					HashSet<String> replaceSet = new HashSet<>();
            					for (String pair : parallelpairsSet) {
            						System.out.println("pair**************"+pair);
            						String aa= resSet.iterator().next();
            						System.out.println("aa**************"+aa);
            			            String bb= word1;
            			            System.out.println("bb**************"+bb);
            						String newpair=pair.replaceAll(resSet.iterator().next(),word1);
            						System.out.println("pair.replaceAll(aa,bb);"+pair.replaceAll(aa,bb));
            			            System.out.println("newnewnewpair"+pair);
            			            replaceSet.add(newpair);
//            			            pair=pair.replace(resSet.iterator().next(),word1);
//            			            System.out.println("newpair"+pair);
//            			            pair.replaceFirst(resSet.iterator().next(),word1);
//            			            System.out.println("newpair2:"+pair);
            			            
//            			            String words = "E,B";
//            			            String newStr = words.replaceFirst("B","F ");
//            			            System.out.println("newStr************************************************"+newStr);    // �������� java,hello php
//            			            String a="B";
//            			            String b="F";
//            			            String newStr1 = words.replace(a,b);
//            			            System.out.println("newStr1**************************"+newStr1);    // 
//            			            String newStr2 = words.replaceAll("hello","��� ");
//            			            System.out.println("newStr2**************************"+newStr2);    // 
            					} 
            					
        			           
            					System.out.println("******RelationMap.get(resSet.iterator().next())**************************"+RelationMap.get(resSet.iterator().next()));
            					System.out.println("%%%%%%%%parallelpairsSet%%%%%%%%%"+replaceSet);
            					if(RelationMap.get(resSet.iterator().next()).containsAll(replaceSet)) {
            						System.out.println("~~~~~~~~~��һ��һ���ǲ����ṹ�еķ��ظ�����~~~~~~~~");
            						deleteactivity.add(word1);
            						parallelNoDupSet.add(word1);
            					}
            					else {
                    				System.out.println("ѭ���ṹ�е��ظ�����");
                        		}
//            					System.out.println("resSet.iterator().next()"+resSet.iterator().next());
//            					System.out.println("resSet.iterator().next()!=word1%%%%%"+resSet.iterator().next()==word1);
//            					System.out.println("resSet.toString()"+resSet.toString()+"word1"+word1);
//                				System.out.println("�����ṹ�еķ��ظ�����");
                				//deleteactivity.add(word1);
                			}
                			else {
                				System.out.println("ѭ���ṹ�е��ظ�����");
                    		}
            			}
            		}     
            		else {
            			deleteactivity.add(word1);
            			parallelNoDupSet.add(word1);
            			System.out.println("���ڻ����3����ڲ����ṹ�еķ��ظ�����");
            		}
            }
        }}
        System.out.println("��ǰ�ڶ���ɸѡdeleteactivityΪ��" + deleteactivity);
        System.out.println("parallelNoDupSet��" + parallelNoDupSet);
        CandidateActivitySet.removeAll(deleteactivity);
    	deleteactivity.clear();
    	
        System.out.println("��ǰ�ڶ���ɸѡCandidateActivitySetΪ��" + CandidateActivitySet);
        
        //������ɸѡʱ��ȥ�����ֺ�ǰ�����̺������ṹ�л�ķ��ظ�����
        for (String word2 : CandidateActivitySet) {
        	System.out.println("���������ɸѡ��������" );
        	for(String parallelword : parallelNoDupSet) {
        		if(PreMap.get(word2).contains(parallelword)||SuccMap.get(word2).contains(parallelword)) {
        			System.out.println(word2+"��ǰ�������а��������ṹ��������" );
        			if((PreNum.get(word2)+SuccNum.get(word2)-1)==PairsNum.get(word2)) {
        				deleteactivity.add(word2);
        			}
            	}
        	}
        	
        }
        CandidateActivitySet.removeAll(deleteactivity);
    	deleteactivity.clear();
        System.out.println("��ǰ������ɸѡCandidateActivitySetΪ��" + CandidateActivitySet);
        
        
        //��ǰ���ǰ������Ϊ1����̻֮�����˳���ϵ  ���� ����̻������2����1������ǿռ���ʱ���ûΪ�ظ�����
        HashSet<String> smallDupSet = new HashSet<>();
        HashSet<String> smallcandiDupSet = new HashSet<>();
        for (String word3 : CandidateActivitySet) {
        	System.out.println("������Ĵ�ɸѡ��������" );
        	if(PreNum.get(word3)==1) {
        		smallcandiDupSet.add(word3);
        		if(SuccMap.get(word3).contains("null")) {
        			smallDupSet.add(word3);
        		}
        		else if(event2number.get(word3)!=tracenumber){
        			//��ǰ����
            		for(String word3succ : SuccMap.get(word3)) {
            			//��ǰ���̵�ǰ��
            			for(String word3succPre :PreMap.get(word3succ)) {
            				if(SuccMap.get(word3).contains(word3succPre)) {
            					smallDupSet.add(word3);
            				}
            			}
            			
            		}
        		}
        	}
        }
        //Ҫ�Ӻ�ѡ�ظ�����������ȥ�����ظ��������Ƚ����¼��Ͻ���ѡ�ظ��������и���һ�ݵ�CandiNoDupSet������ȥ���ظ����񼯺ϣ����µĲ��ּ���Ϊ���ظ�������Ӻ�ѡ�ظ�����������ȥ��
        Set<String> CandiNoDupSet = new HashSet<>();
        CandiNoDupSet.addAll(smallcandiDupSet);
        System.out.println("4CandiNoDupSetΪ��" + CandiNoDupSet);
        CandiNoDupSet.removeAll(smallDupSet);
        System.out.println("4ɾCandiNoDupSetΪ��" + CandiNoDupSet);
        deleteactivity.addAll(CandiNoDupSet);
        System.out.println("4 deleteactivityΪ��" +  deleteactivity);
        
        
        CandidateActivitySet.removeAll(deleteactivity);
        System.out.println("4 CandidateActivitySet.removeAll(deleteactivity)��" +  CandidateActivitySet);
        
    	deleteactivity.clear();
        System.out.println("��ǰ���Ĵ�ɸѡCandidateActivitySetΪ��" + CandidateActivitySet);
        
        
      //��ǰ��ĺ�̸���Ϊ1��ǰ���֮�����˳���ϵ  ���� ��ǰ���������2����1��ǰ���ǿռ���ʱ���ûΪ�ظ�����
        HashSet<String> smallDupSet1 = new HashSet<>();
        HashSet<String> smallcandiDupSet1 = new HashSet<>();
        for (String word4 : CandidateActivitySet) {
        	
        	System.out.println("��������ɸѡ��������"+word4 );
        	if(SuccNum.get(word4)==1) {
        		smallcandiDupSet1.add(word4);
        		System.out.println("$$$$$$$$$$$$smallcandiDupSet��������"+smallcandiDupSet1 );
        		if(PreMap.get(word4).contains("null")) {
        			smallDupSet1.add(word4);
        		}
        		else if(event2number.get(word4)!=tracenumber){
        			//��ǰ����
            		for(String word4pre : PreMap.get(word4)) {
            			//��ǰ���̵�ǰ��
            			for(String word4prePre :PreMap.get(word4pre)) {
            				if(PreMap.get(word4).contains(word4prePre)) {
            					smallDupSet1.add(word4);
            				}
            			}
            			
            		}
        		}
        	}
        }
        //Ҫ�Ӻ�ѡ�ظ�����������ȥ�����ظ��������Ƚ����¼��Ͻ���ѡ�ظ��������и���һ�ݵ�CandiNoDupSet������ȥ���ظ����񼯺ϣ����µĲ��ּ���Ϊ���ظ�������Ӻ�ѡ�ظ�����������ȥ��
        Set<String> CandiNoDupSet1 = new HashSet<>();
        CandiNoDupSet1.addAll(smallcandiDupSet1);
        System.out.println("5CandiNoDupSet1Ϊ��" + CandiNoDupSet1);
        System.out.println("5smallDupSet1Ϊ��" + smallDupSet1);
        CandiNoDupSet1.removeAll(smallDupSet1);
        System.out.println("5ɾCandiNoDupSet1Ϊ��" + CandiNoDupSet1);
        deleteactivity.addAll(CandiNoDupSet1);
        System.out.println("5 deleteactivityΪ��" +  deleteactivity);
        
        CandidateActivitySet.removeAll(deleteactivity);
    	deleteactivity.clear();
        System.out.println("��ǰ�����ɸѡCandidateActivitySetΪ��" + CandidateActivitySet);
        
        
//      for (String word4 : preORsuccIS1Set) {
//    	
//    }
        
        
//        //ǰ���Ϊ2&&��ϵ��Ϊ4��ǰ��֮��Ϊ3
//        for (String word : CandidateActivitySet) {
//        	System.out.println("word:======>"+word);
//            if((PreNum.get(word)==1&&SuccNum.get(word)==1)||(PreMap.get(word).contains("null")&&PreNum.get(word)==1)||(SuccMap.get(word).contains("null")&&SuccNum.get(word)==1)) {
//            	deleteactivity.add(word);
//            }
//        }
//    	CandidateActivitySet.removeAll(deleteactivity);
//        System.out.println("��ǰCandidateActivitySetΪ��"+CandidateActivitySet);
        
        
//        for (String word : CandidateActivitySet) {
//
//            if(PreNum.get(word)==1) {
//            	System.out.println("@@@@@@@@@@@@@@@@"+word);
//            	System.out.println("@@@@@@@@@@@@@@@@"+PreMap.get(word).contains("null"));
//            	System.out.println("@@@@@@@@@@@@@@@@"+PreMap.get(word));
//            }
//
//        }
        
        
//	    for(String dfrkey: dfr2Sig.keySet()){
//	           // System.out.println("dfriter===>"+dfrkey);
//	            String []act = dfrkey.split(",");
		
//		
//		for(XTrace trace:VariantLog)
//		{
//			HashSet<String> activitySet = new HashSet<>();
//			HashSet<String> successor = new HashSet<>();
//			for(int i=0;i<=trace.size()-1;i++)
//			{
//				while(XConceptExtension.instance().extractName(trace.get(i+1)) == null) {
//					System.out.println("yes========>");
//				    if(SuccessorSet.get(i) == null) {
//						successor.add(XConceptExtension.instance().extractName(trace.get(i+1)));
//						SuccessorSet.put(XConceptExtension.instance().extractName(trace.get(i)), successor);
//					}
//					else {
//						successor = SuccessorSet.get(XConceptExtension.instance().extractName(trace.get(i)));
//						successor.add(XConceptExtension.instance().extractName(trace.get(i+1)));
//						SuccessorSet.put(XConceptExtension.instance().extractName(trace.get(i)), successor);
//					}
//				}
//				while(XConceptExtension.instance().extractName(trace.get(i+1)) == null) {
//				    if(SuccessorSet.get(i) == null) {
//						successor.add("null");
//						SuccessorSet.put(XConceptExtension.instance().extractName(trace.get(i)), successor);
//					}i0
//					else {
//						successor = SuccessorSet.get(XConceptExtension.instance().extractName(trace.get(i)));
//						successor.add("null");
//						SuccessorSet.put(XConceptExtension.instance().extractName(trace.get(i)), successor);
//					}
//				}
//			}
//		}
//		System.out.println("SuccessorSet========>"+SuccessorSet);
//		//step 3 ������־ÿ���켣��ÿ���¼��������Ĺ�ϵ
//		HashMap<String, List<Pair<String,String>>> event2pair_list1 = new HashMap<>();
//		for(XTrace trace : VariantLog) { 
//			//��ÿ���켣�����¼��ַ����ֱ�洢��������
//			int event_num = 0;
//			for(XEvent event: trace) {
//				event_num += 1;
//			}
//			String event_str[]=new String[event_num];
//			int num = 0;
//			for(XEvent event: trace) {
//				event_str[num] = event.getAttributes().get("concept:name").toString();                                                                                          
//				num += 1;
//			}
//			for(int i=0;i<event_num;i++) {
//			System.out.println("event:---------------->"+event_str[i]+"  ");	
//			}
//			System.out.println('\n');
//			
//
//			HashMap<String, List<Pair<String,String>>> duplicate_pairs = new HashMap<>();
//		    //�����켣��ÿ���¼��ҵ���ǰ�¼���ǰ���ͺ�̴洢����ǰ�¼���Ӧ�б���
//			for(int i=0;i<event_num;i++) {
//				HashMap<String, List<Pair<String,String>>> duplicate_pairs1 = new HashMap<>();
//				if(i==0)
//				{
//					List<Pair<String,String>> pair_list1 = new ArrayList<Pair<String,String>>();
//					List<Pair<String,String>> pair_list12 = new ArrayList<Pair<String,String>>();
//					Pair<String, String> pair1 = new Pair<>(null,null);
//					Pair<String, String> pair3 = new Pair<>(null, event_str[i+1]);
//					pair1 = pair3;
//					pair_list12.add(pair1);
//					if(event2pair_list1.containsKey(event_str[i])) {
//						pair_list1.clear();
//						pair_list1.addAll(event2pair_list1.get(event_str[i]));
//						pair_list1.add(pair1);
//						event2pair_list1.put(event_str[i], pair_list1);
//					}
//					else
//					{
//						pair_list1.clear();
//						pair_list1.add(pair1);
//						event2pair_list1.put(event_str[i], pair_list1);
//					}
//					duplicate_pairs1.put(event_str[i], pair_list12);
//				}
//				else if(i==event_num-1) {
//					
//					List<Pair<String,String>> pair_list2 = new ArrayList<Pair<String,String>>();
//					List<Pair<String,String>> pair_list22 = new ArrayList<Pair<String,String>>();
//					Pair<String, String> pair2 = new Pair<>(event_str[i-1],null);
//					if(event2pair_list1.containsKey(event_str[i])) {
//						pair_list2.clear();
//						pair_list2.addAll(event2pair_list1.get(event_str[i]));
//						pair_list2.add(pair2);
//						event2pair_list1.put(event_str[i], pair_list2);
//					}
//					else{
//						pair_list2.clear();
//						pair_list2.add(pair2);
//						event2pair_list1.put(event_str[i], pair_list2);
//					}
//					if(duplicate_pairs1.containsKey(event_str[i])) {
//						pair_list22.addAll(event2pair_list1.get(event_str[i]));
//						pair_list22.add(pair2);
//						duplicate_pairs1.put(event_str[i], pair_list22);
//					}
//					else {
//						pair_list22.add(pair2);
//						duplicate_pairs1.put(event_str[i], pair_list22);
//					}
//				}
//				else {
//					List<Pair<String,String>> pair_list3 = new ArrayList<Pair<String,String>>();
//					List<Pair<String,String>> pair_list32 = new ArrayList<Pair<String,String>>();
//					Pair<String, String> pair3 = new Pair<>(event_str[i-1],event_str[i+1]);
//					if(event2pair_list1.containsKey(event_str[i])) {
//						pair_list3.clear();
//						pair_list3.addAll(event2pair_list1.get(event_str[i]));
//						pair_list3.add(pair3);
//						event2pair_list1.put(event_str[i], pair_list3);
//					}
//					else
//					{
//						pair_list3.clear();
//						pair_list3.add(pair3);
//						event2pair_list1.put(event_str[i], pair_list3);
//					}
//					if(duplicate_pairs1.containsKey(event_str[i])) {
//						pair_list32.addAll(event2pair_list1.get(event_str[i]));
//						pair_list32.add(pair3);
//						duplicate_pairs1.put(event_str[i], pair_list32);
//					}
//					else {
//						pair_list32.add(pair3);
//						duplicate_pairs1.put(event_str[i], pair_list32);
//					}
//				}
//				System.out.println(" duplicate_pairs1 :---------------->"+ duplicate_pairs1);
//			}
//		}
//        //ȥ��
//		HashMap<String, List<Pair<String,String>>> event2pair_list = new HashMap<>();
//		for (String key : event2pair_list1.keySet()) {
//		    List<Pair<String,String>> pair_list0 = new ArrayList<Pair<String,String>>();
//		    List<Pair<String,String>> pair_list = new ArrayList<Pair<String,String>>();
////		    ʾ����pair_list0:---------------->[d=null, d=null, c=null, d=null]
//		    pair_list0.addAll(event2pair_list1.get(key));
//		    for (Pair<String,String> str : pair_list0) {
//			       if (!pair_list.contains(str)) {
//			    	   pair_list.add(str);
//			       }
//			   }
////	            ʾ����pair_list:---------------->[d=null, c=null]
//		    event2pair_list.put(key, pair_list);
//		}
//	    System.out.println("event2pair_list:---------------->"+event2pair_list);
//	    
//	    for (String key : event2pair_list.keySet()) {
//	    	List<Pair<String,String>> pair_list_num = new ArrayList<Pair<String,String>>();
//	    	pair_list_num.addAll(event2pair_list.get(key));
//	    	int num = pair_list_num.size();
//	    	System.out.println("num***********=" + num);
//	    }
//	    
	    
	    
//		//step 2  ���dfgת����petri��
//		return IMd.minePetriNet(context,dfg);
        return CandidateActivitySet;
        
	}
	
//	//�׳�
//	public static long factorial(long number) {
//        if (number <= 1)
//            return 1;
//        else
//            return number * factorial(number - 1);
//    }
	
}
