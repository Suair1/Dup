package MingPetriNetUsingTransitionsystemToProcessTree;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.deckfour.xes.classification.XEventAndClassifier;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.classification.XEventLifeTransClassifier;
import org.deckfour.xes.classification.XEventNameClassifier;
import org.deckfour.xes.classification.XEventResourceClassifier;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.acceptingpetrinet.models.AcceptingPetriNet;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.packages.PackageManager.Canceller;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.transitionsystem.State;
import org.processmining.models.graphbased.directed.transitionsystem.Transition;
import org.processmining.models.graphbased.directed.transitionsystem.TransitionSystem;
import org.processmining.plugins.InductiveMiner.efficienttree.EfficientTreeReduce.ReductionFailedException;
import org.processmining.plugins.InductiveMiner.efficienttree.UnknownTreeNodeException;
import org.processmining.plugins.inductiveminer2.variants.MiningParametersIM;
import org.processmining.plugins.inductiveminer2.withoutlog.dfgmsd.DfgMsd;
import org.processmining.plugins.inductiveminer2.withoutlog.dfgmsd.DfgMsdImpl;
import org.processmining.plugins.inductiveminer2.withoutlog.dfgmsd.Log2DfgMsd;
import org.processmining.plugins.inductiveminer2.withoutlog.variants.MiningParametersIMWithoutLog;
import org.processmining.plugins.transitionsystem.converter.util.TSConversions;
import org.processmining.plugins.transitionsystem.miner.TSMiner;
import org.processmining.plugins.transitionsystem.miner.modir.TSMinerModirInput;
import org.processmining.plugins.transitionsystem.miner.util.TSAbstractions;
import org.processmining.plugins.transitionsystem.miner.util.TSDirections;


//in inductive miner package



public class MineDuplicateTasksFixedConfigTrial
{
		@Plugin(
                name = "Duplicate Tasks Miner Plugin", 
                
                parameterLabels = {"Event Log"}, 
            	returnLabels = {"Petri net"}, //return labels
            	returnTypes = {Petrinet.class },//return class
//                returnLabels = { "AcceptingPetriNet" }, 
//                returnTypes = { DfgMsd.class }, 
                userAccessible = true, 
                help = "This plugin aims to mine an input event log with duplicate tasks and returns a precise process model by using the context relation and transition system."
                )     
        @UITopiaVariant(
                affiliation = "SDUT", 
                author = "Xuan Su", 
    	        email = "15715325632@163.com"
                       )     
 @PluginVariant(variantLabel = "Choose mining mode and optional noise threshold", requiredParameterLabels = {0})
 public static Petrinet MiningPetriNetByTransitionSystem(UIPluginContext context, XLog log) throws UnknownTreeNodeException, ReductionFailedException 
//    public static DfgMsd MiningPetriNetByTransitionSystem(UIPluginContext context, XLog log) throws UnknownTreeNodeException, ReductionFailedException 
    {
        MiningOptions options = new MiningOptions();
        org.deckfour.uitopia.api.event.TaskListener.InteractionResult result =
            context.showWizard("Duplicate Tasks Miner Plugin", true, true, options);
        if (result != org.deckfour.uitopia.api.event.TaskListener.InteractionResult.FINISHED) {
            context.getFutureResult(0).cancel(false);
            return null;
        }
        try {
            return mineConfigured(context, log, options.withNoise(), options.threshold());
        } catch (IllegalStateException error) {
            String message = error.getMessage();
            if (message == null || !(message.contains("renamed occurrence mapping") || message.contains("Expected one renamed trace"))) { throw error; }
            context.log(message);
            javax.swing.JOptionPane.showMessageDialog(null,
                "Task contexts could not be resolved uniquely for this log.\n"
                + "Noise filtering cannot resolve every context ambiguity.\n"
                + "No model has been returned; inspect the log or compare with standard IM/IMf.",
                "Duplicate Tasks Miner Plugin", javax.swing.JOptionPane.WARNING_MESSAGE);
            context.getFutureResult(0).cancel(false);
            return null;
        }
    }

    public static Petrinet mineConfigured(final PluginContext context, XLog log, boolean infrequent, float noiseThreshold)
            throws UnknownTreeNodeException, ReductionFailedException {
        AcceptingPetriNet model = mineAcceptingConfigured(context, log, infrequent, noiseThreshold);
        return model == null ? null : model.getNet();
    }

    public static AcceptingPetriNet mineAcceptingConfigured(final PluginContext context, XLog log,
            boolean infrequent, float noiseThreshold) throws UnknownTreeNodeException, ReductionFailedException {
        if (Float.isNaN(noiseThreshold) || noiseThreshold < 0 || noiseThreshold > 1) {
            throw new IllegalArgumentException("Noise threshold must be between 0 and 1");
        }

                        
            HashSet<String> CandidateActivitySet = DuplicateTasks.DuplicateTasksMining(context instanceof UIPluginContext ? (UIPluginContext) context : null, log);
            if (CandidateActivitySet.isEmpty()) {
                org.processmining.plugins.inductiveminer2.variants.MiningParametersIM parameters =
                    infrequent ? new org.processmining.plugins.inductiveminer2.variants.MiningParametersIMInfrequent()
                    : new org.processmining.plugins.inductiveminer2.variants.MiningParametersIM();
                parameters.setNoiseThreshold(noiseThreshold);
                parameters.setClassifier(new XEventNameClassifier());
                AcceptingPetriNet plain = InductiveMinerPlugin.minePetriNet(parameters.getIMLog(log), parameters,
                    new Canceller() { public boolean isCancelled() { return context.getProgress().isCancelled(); } });
                return plain;
            }

            
            System.out.println("CandidateActivitySet=>"+CandidateActivitySet);
            for(String candi : CandidateActivitySet){
                System.out.println("candi=>"+candi);
            }
            HashMap<Transition, Transition> TransitionRelation=new HashMap<Transition, Transition>();
            HashMap<String, Integer> TransitionLabel=new HashMap<String, Integer>();     
 
                    
            XEventClassifier[] classifiers = new XEventClassifier[3];
            classifiers[0] = new XEventNameClassifier();
            classifiers[1] = new XEventResourceClassifier();
            classifiers[2] = new XEventLifeTransClassifier();
            XEventClassifier transitionClassifier = new XEventAndClassifier(new XEventNameClassifier(),new XEventLifeTransClassifier());
         
            // Fixed TS settings replace the interactive wizard.
         
    		
            Object[] objects= mineFixedTransitionSystem(context, log, Arrays.asList(classifiers), transitionClassifier); 
            if (objects == null || objects[0] == null || context.getProgress().isCancelled()) { return null; }
            TransitionSystem result=(TransitionSystem) objects[0];

            
          int i=0;
          int transitionNum=result.getEdges().size();
          Transition[] transitions = new Transition[transitionNum] ;
          String[] activity= new  String[transitionNum];
//          int flag=0;
          for(Transition t:result.getEdges())
          {
        	  transitions[i++]=t;
          }

          
                                                                                                          
          for(i=0;i<transitions.length;i++)
                                                               {
        	if(CandidateActivitySet.contains(transitions[i].getLabel().replace("+complete", ""))) {
                                                          
        	        if(TransitionLabel.containsKey(transitions[i].getLabel()))
        	        {  TransitionLabel.put(transitions[i].getLabel(), TransitionLabel.get(transitions[i].getLabel())+1);
//        	           System.out.println("yes!!!TransitionLabel:"+transitions[i].getLabel()+"::::::"+TransitionLabel.get(transitions[i].getLabel()));
        	        }
        	        else {
        	           TransitionLabel.put(transitions[i].getLabel(), 0); 
//        	           System.out.println("no!!!TransitionLabel:"+transitions[i].getLabel()+":::::"+TransitionLabel.get(transitions[i].getLabel()));
        	        }
        	}
        	else {
                                                               
        		TransitionLabel.put(transitions[i].getLabel(), 0);
        	}
        	 
            	                                   
             
          if(TransitionLabel.get(transitions[i].getLabel())==0)
          {   
                                                                                                 
        	  transitions[i].setLabel(transitions[i].getLabel());
                                                                                                 
          }else { 
                                                                                                 
        	  transitions[i].setLabel(transitions[i].getLabel()+":"+TransitionLabel.get(transitions[i].getLabel()).toString());
                                                                                                   
          }                               

//          if(activity[i].contains("+start"))
//            flag=1;  
          }            

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                      
                                                                                                    
        for(Transition s:transitions) {
            for (Transition e:transitions)                                  
            {
            System.out.println("s=====>"+s+"||||e=======>"+e);
            System.out.println("s.getTarget().getLabel()=====>"+s.getTarget().getLabel()+"s.getSource().getLabel()=====>"+s.getSource().getLabel()+"||||e.getTarget().getLabel()=======>"+e.getTarget().getLabel()+"||||e.getSource().getLabel()=======>"+e.getSource().getLabel());
            if(s.getTarget().getLabel().equals(e.getSource().getLabel()))
            { 
            Transition  transition=new  Transition(s.getSource(), s.getTarget(), new Object()) ;
            transition.setLabel(s.getLabel());
            TransitionRelation.put(transition, e);	
            System.out.println("@@@@@@transition.getLabel:=>"+transition.getLabel());
            System.out.println("@@@@@@TransitionRelation:=>"+TransitionRelation);
                  } 
            }}
                                
        HashMap<Transition, Transition> NewTransitionRelation=new HashMap<Transition, Transition>();
        int changenum = 0;
        ////////////////////////////////////////////////////////////////
        for(String candiac : CandidateActivitySet){       	
        	String candiacname = candiac+"+complete";
        	System.out.println("CANDIAC==>"+candiac+"TransitionLabel.get(candiac)"+TransitionLabel.get(candiacname));
        	
        	                                             
        	if(TransitionLabel.get(candiacname)==0) {
        		System.out.println("yesyesyes!!!!!!!!!TransitionLabel.get(candiacname)==0");
        		if(changenum==0) {
        			NewTransitionRelation.putAll(TransitionRelation);
        		}
        		
        	                              
        		HashMap<Transition, Transition> includeCandiTransitionRelation=new HashMap<Transition, Transition>();
        		HashMap<Transition, Transition> noincludeCandiTransitionRelation=new HashMap<Transition, Transition>();
        	    for(Transition keystrans:NewTransitionRelation.keySet()){
        	    	                               
        	    	if(keystrans.getLabel().equals(candiacname)||NewTransitionRelation.get(keystrans).getLabel().equals(candiacname)) {
        	    		includeCandiTransitionRelation.put(keystrans, NewTransitionRelation.get(keystrans));
        	    	}
        	    	else {
        	    		noincludeCandiTransitionRelation.put(keystrans, NewTransitionRelation.get(keystrans));
        	    	}
        	    }
        	    
        	    System.out.println("^^^^^includeCandiTransitionRelation:=>"+includeCandiTransitionRelation);
        	    System.out.println("^^^^^^noincludeCandiTransitionRelation=>"+noincludeCandiTransitionRelation);
        		
        	   // @@@@@@$$$$$BeforeTransitionRelation1:=>{B+complete:1=A+complete:2, B+complete:3=C+complete}
        	   // @@@@@@$$$$$AfterTransitionRelation1:=>{A+complete:1=B+complete:2, C+complete=B+complete:1, E+complete=B+complete:3, D+complete=B+complete}
        		                     
        		HashMap<Transition, Transition> BeforeTransitionRelation=new HashMap<Transition, Transition>();
        		                     
        		HashMap<Transition, Transition> AfterTransitionRelation=new HashMap<Transition, Transition>();
        		
        		                                                                       
        		for(Transition allkeytrans:includeCandiTransitionRelation.keySet()) {
        			//System.out.println("$$$$$allkeytrans.getLabel().replace(\"+complete\", \"\"):=>"+allkeytrans.getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
        			if(allkeytrans.getLabel().replace("+complete", "").equals(candiac)) {
        				                              
        				BeforeTransitionRelation.put(allkeytrans, NewTransitionRelation.get(allkeytrans));
//        				System.out.println("@@@@@@$$$$$BeforeTransitionRelation:=>"+BeforeTransitionRelation);
        			}
        			//System.out.println("||TransitionRelation.get(allkeytrans).getLabel().replace(\"+complete\", \"\")"+TransitionRelation.get(allkeytrans).getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
        			
        			if(NewTransitionRelation.get(allkeytrans).getLabel().replace("+complete", "").equals(candiac)) {
        				                                 
        				AfterTransitionRelation.put(allkeytrans, NewTransitionRelation.get(allkeytrans));
//        				System.out.println("@@@@@@$$$$$AfterTransitionRelation:=>"+AfterTransitionRelation);
        			}
        		}
        		System.out.println("@@@@@@$$$$$BeforeTransitionRelation:=>"+BeforeTransitionRelation);
        		System.out.println("@@@@@@$$$$$AfterTransitionRelation:=>"+AfterTransitionRelation);
        		System.out.println("SIZE===>"+BeforeTransitionRelation.size()+"||aftersize==>"+AfterTransitionRelation.size());
        		     		
        		
        		if(BeforeTransitionRelation.size()>1&&AfterTransitionRelation.size()==1) {
        			System.out.println("\u6ee1\u8db3\u6761\u4ef6\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01\uff01");
        			int count = 1;
        			                                    
        			for(Transition beforekeytrans:BeforeTransitionRelation.keySet()) {
        				System.out.println("beforekeytrans===>"+beforekeytrans+"beforetrans,source===>"+beforekeytrans.getSource()+"beforekeytrans.target===>"+beforekeytrans.getTarget());
        				Transition  newtransition=new  Transition(beforekeytrans.getSource(), beforekeytrans.getTarget(), new Object()) ;
        		        String newlabel = beforekeytrans.getLabel()+":"+ count;
        		        System.out.println("newlabel==>"+newlabel);
        		        newtransition.setLabel(newlabel);
        		        noincludeCandiTransitionRelation.put(newtransition, BeforeTransitionRelation.get(beforekeytrans));
        		        //System.out.println("~~~~~~~~AfterTransitionRelation.get(beforekeytrans)==>"+AfterTransitionRelation.get(beforekeytrans));
        		        System.out.println("!!!!!!!!newtransition==>"+newtransition.getLabel());
        		       
        		        for(Transition afterkeytrans:AfterTransitionRelation.keySet()) {
        		        	System.out.println(" afterkeytrans==>"+ afterkeytrans+"||AfterTransitionRelation.get(afterkeytrans)=>"+AfterTransitionRelation.get(afterkeytrans));
//        		        	Transition  newtransition1=new  Transition(AfterTransitionRelation.get(afterkeytrans).getSource(), AfterTransitionRelation.get(afterkeytrans).getTarget(), new Object()) ;
//            		        String newlabel1 = beforekeytrans.getLabel()+":"+ count;
//            		        newtransition1.setLabel(newlabel1);
//            		        System.out.println("newtransition1==>"+newtransition1.getLabel());
        		        	Transition  newtransition1=new  Transition(afterkeytrans.getSource(), afterkeytrans.getTarget(), new Object()) ;
            		        String newlabel1 = afterkeytrans.getLabel();
            		        newtransition1.setLabel(newlabel1);
        		        	noincludeCandiTransitionRelation.put( newtransition1, newtransition);
        		        	System.out.println("~~~~~~~~!!noincludeCandiTransitionRelation==>"+noincludeCandiTransitionRelation);
        		        }
        		        
        		        System.out.println("~~~~~~~~00000noincludeCandiTransitionRelation==>"+noincludeCandiTransitionRelation);
        		        count++;
        			}
        			//TransitionRelation.remove(candiacname);
        		}
        		
        		
//        		if(AfterTransitionRelation.size()>1&&BeforeTransitionRelation.size()==1) {
                                                                    
//        			int count = 1;
                                                 
//        			for(Transition afterkeytrans:AfterTransitionRelation.keySet()) {
//        				System.out.println("afterkeytrans===>"+afterkeytrans+"aftertrans,source===>"+afterkeytrans.getSource()+"afterkeytrans.target===>"+afterkeytrans.getTarget());
//        				Transition  newtransition=new  Transition(afterkeytrans.getSource(), afterkeytrans.getTarget(), new Object()) ;
//        		        String newlabel = afterkeytrans.getLabel()+":"+ count;
//        		        System.out.println("newlabel==>"+newlabel);
//        		        newtransition.setLabel(newlabel);
//        		        noincludeCandiTransitionRelation.put(newtransition, AfterTransitionRelation.get(afterkeytrans));
//        		        //System.out.println("~~~~~~~~AfterTransitionRelation.get(afterkeytrans)==>"+AfterTransitionRelation.get(afterkeytrans));
//        		        System.out.println("!!!!!!!!newtransition==>"+newtransition.getLabel());
//        		       
//        		        for(Transition beforekeytrans:BeforeTransitionRelation.keySet()) {
//        		        	System.out.println(" beforekeytrans==>"+ beforekeytrans+"||beforeTransitionRelation.get(afterkeytrans)=>"+BeforeTransitionRelation.get(beforekeytrans));
//        		        	Transition  newtransition1=new  Transition(beforekeytrans.getSource(), beforekeytrans.getTarget(), new Object()) ;
//            		        String newlabel1 = beforekeytrans.getLabel();
//            		        newtransition1.setLabel(newlabel1);
//        		        	noincludeCandiTransitionRelation.put( newtransition1, newtransition);
//        		        	System.out.println("~~~~~~~~!!noincludeCandiTransitionRelation==>"+noincludeCandiTransitionRelation);
//        		        }
//        		        
//        		        System.out.println("~~~~~~~~00000noincludeCandiTransitionRelation==>"+noincludeCandiTransitionRelation);
//        		        count++;
//        			}
//        			//TransitionRelation.remove(candiacname);
//        		}
        		NewTransitionRelation.clear();
        		NewTransitionRelation.putAll(noincludeCandiTransitionRelation);
        		changenum=1;
        	}       	
        	 	
        	                
        	                                                                                   
        	else if(TransitionLabel.get(candiacname)>1){
        		System.out.println("--------------------------------------------------------");
                System.out.println("yesyes!!!!!TransitionLabel.get(candiacname)>0||||||"+candiac);
                System.out.println("--------------------------------------------------------");
        	                              
        		HashMap<Transition, Transition> includeCandiTransitionRelation1=new HashMap<Transition, Transition>();
        		HashMap<Transition, Transition> noincludeCandiTransitionRelation1=new HashMap<Transition, Transition>();
        		                                                                             
        		HashSet<String> canditransitions=new HashSet<String>();
        		if(changenum==0) {
        			NewTransitionRelation.putAll(TransitionRelation);
        		}
//        		System.out.println("*************************************NewTransitionRelation:=>"+NewTransitionRelation);
//        		System.out.println("******************NewTransitionRelation.keySet()=>"+NewTransitionRelation.keySet());
        		for(Transition keystrans:NewTransitionRelation.keySet()){
        			
        			System.out.println("*************************************");
        			System.out.println("candiacname=>"+candiacname+"||keystrans=>"+keystrans+"||"+NewTransitionRelation.get(keystrans));
        			System.out.println("*************************************");
        	    	                                   
//        			System.out.println("keystrans.getLabel()====>"+keystrans.getLabel());
//        			System.out.println("candiacnam====>"+candiacname);
//        			System.out.println("keystrans.getLabel().split(\":\")[0]====>"+keystrans.getLabel().split(":")[0]);
//        			System.out.println("keystrans.getLabel()====>"+keystrans.getLabel());
        	    	if(keystrans.getLabel().equals(candiacname)||keystrans.getLabel().split(":")[0].equals(candiacname)) {
//        	    		System.out.println("1111111111111111111111111111111111111111111");
//        	    		System.out.println("!!TransitionRelation.get(keystrans).getLabel()==>"+NewTransitionRelation.get(keystrans).getLabel()+"||keystrans.getLabel()=>"+keystrans.getLabel());
        	    		
        	    		includeCandiTransitionRelation1.put(keystrans, NewTransitionRelation.get(keystrans));
        	    	//	System.out.println("1111includeCandiTransitionRelation1=>"+includeCandiTransitionRelation1);
        	    		canditransitions.add(keystrans.getLabel());
//        	    		if(keystrans.getLabel().indexOf(":")!=0) {
//        	         		  activity[i]=activity[i].split(":")[0];
//        	         		  canditransitions.add(keystrans.getLabel().split(":")[0],keystrans.getLabel());
//        	         	  }
//        	    		else {
//        	    			  canditransitions.add(keystrans.getLabel(),keystrans.getLabel());
//        	    		}
        	    		//System.out.println("canditransitions==>"+canditransitions);
        	    		
        	    	}
        	    	else if(NewTransitionRelation.get(keystrans).getLabel().equals(candiacname)||NewTransitionRelation.get(keystrans).getLabel().split(":")[0].equals(candiacname)) {
//        	    		System.out.println("2222222222222222222222222222222222222222222222222222");
//        	    		System.out.println("~~~TransitionRelation.get(keystrans).getLabel()==>"+NewTransitionRelation.get(keystrans).getLabel()+"||keystrans.getLabel()=>"+keystrans.getLabel());
        	    		includeCandiTransitionRelation1.put(keystrans, NewTransitionRelation.get(keystrans));
        	    		//System.out.println("222includeCandiTransitionRelation1=>"+includeCandiTransitionRelation1);
        	    		canditransitions.add(NewTransitionRelation.get(keystrans).getLabel());
        	    	//	System.out.println("canditransitions1==>"+canditransitions);
        	    		
        	    	}
        	    	else {
        	    	//	System.out.println("33333333333333333333333333333333333333333333");
        	    		noincludeCandiTransitionRelation1.put(keystrans, NewTransitionRelation.get(keystrans));
        	    	}
//        	    	  System.out.println("^^^^^000includeCandiTransitionRelation1:=>"+includeCandiTransitionRelation1);
//        	    	    System.out.println("^^^^^^000noincludeCandiTransitionRelation1=>"+noincludeCandiTransitionRelation1);
        	    }
        	    
        	    System.out.println("^^^^^includeCandiTransitionRelation1:=>"+includeCandiTransitionRelation1);
        	    System.out.println("^^^^^^noincludeCandiTransitionRelation1=>"+noincludeCandiTransitionRelation1);
        		
        	
        	                       
        		HashMap<Transition, Transition> BeforeTransitionRelation1=new HashMap<Transition, Transition>();
        		                     
        		HashMap<Transition, Transition> AfterTransitionRelation1=new HashMap<Transition, Transition>();
        		
        		                                                                       
        		for(Transition allkeytrans:includeCandiTransitionRelation1.keySet()) {
        			//System.out.println("$$$$$allkeytrans.getLabel().replace(\"+complete\", \"\"):=>"+allkeytrans.getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
        			if(allkeytrans.getLabel().equals(candiacname)||allkeytrans.getLabel().split(":")[0].equals(candiacname)) {
        				                              
        				BeforeTransitionRelation1.put(allkeytrans, NewTransitionRelation.get(allkeytrans));
//        				System.out.println("@@@@@@$$$$$BeforeTransitionRelation:=>"+BeforeTransitionRelation);
        			}
        			//System.out.println("||TransitionRelation.get(allkeytrans).getLabel().replace(\"+complete\", \"\")"+TransitionRelation.get(allkeytrans).getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
        			
        			if(NewTransitionRelation.get(allkeytrans).getLabel().equals(candiacname)||NewTransitionRelation.get(allkeytrans).getLabel().split(":")[0].equals(candiacname)) {
        				                                 
        				AfterTransitionRelation1.put(allkeytrans, NewTransitionRelation.get(allkeytrans));
//        				System.out.println("@@@@@@$$$$$AfterTransitionRelation:=>"+AfterTransitionRelation);
        			}
        			
        		}
        		
//        		@@@@@@$$$$$BeforeTransitionRelation1:=>{A+complete:1=F+complete, A+complete:2=C+complete, A+complete:2=B+complete, A+complete=D+complete}
//              @@@@@@$$$$$AfterTransitionRelation1:=>{X+complete=A+complete:2, D+complete=A+complete:1, B+complete:2=A+complete}
//        		System.out.println("@@@@@@$$$$$BeforeTransitionRelation1:=>"+BeforeTransitionRelation1);
//        		System.out.println("@@@@@@$$$$$AfterTransitionRelation1:=>"+AfterTransitionRelation1);
//        		System.out.println("SIZE===>"+BeforeTransitionRelation1.size()+"||aftersize==>"+AfterTransitionRelation1.size());
        		
        		
        		
        		       
        		 List<String> canditransitionslist = new ArrayList<String>();

        	      for (String a : canditransitions) {
        	         canditransitionslist.add(a);
        	      }
//        	      System.out.println("`````````canditransitionslists=>"+canditransitionslist);
//        	      for(int iii=0;iii<canditransitionslist.size();iii++) {
//        	    	  System.out.println("~```````````canditransitionslist.get(iii)==>"+canditransitionslist.get(iii));
//        	      }

        	      
          		for (int a1 = 0; a1 < canditransitionslist.size(); a1++) {
          			System.out.println("a1======>"+a1+"|canditransitionslist=>"+canditransitionslist.get(a1));
//                   for (int a2 = canditransitionslist.size() - 1; a2 > a1; a2--) {
          			for (int a2 = 0; a2 < canditransitionslist.size(); a2++) {
                    if (a1 == a2 || !canditransitions.contains(canditransitionslist.get(a1))
                            || !canditransitions.contains(canditransitionslist.get(a2))) { continue; }

                	System.out.println("a2======>"+a2+"|canditransitionslist=>"+canditransitionslist.get(a2));
                	
        				                      
        				HashSet<String> Beforea1Set=new HashSet<String>();
        				HashSet<String> Aftera1Set=new HashSet<String>();
        				HashSet<String> Beforea2Set=new HashSet<String>();
        				HashSet<String> Aftera2Set=new HashSet<String>();
        				                                                                                                                        
        				for(Transition allBefore:AfterTransitionRelation1.keySet()) {
        					
        					if(Objects.equals(AfterTransitionRelation1.get(allBefore).getLabel(), canditransitionslist.get(a1))) {
        						Beforea1Set.add(allBefore.getLabel());
        					}
        					if(Objects.equals(AfterTransitionRelation1.get(allBefore).getLabel(), canditransitionslist.get(a2))) {
        						Beforea2Set.add(allBefore.getLabel());
        					}
        				}
        				                                                                                                                                                
                        for(Transition allAfter:BeforeTransitionRelation1.keySet()) {
        					if(Objects.equals(allAfter.getLabel(), canditransitionslist.get(a1))) {
        						Aftera1Set.add(BeforeTransitionRelation1.get(allAfter).getLabel());
        					}
        					if(Objects.equals(allAfter.getLabel(), canditransitionslist.get(a2))) {
        						Aftera2Set.add(BeforeTransitionRelation1.get(allAfter).getLabel());
        					}
        				}
//                        System.out.println("//////////////////////////////////////////");
//                        System.out.println("Beforea1Set:=>"+Beforea1Set);
//                        System.out.println("Beforea2Set:=>"+Beforea2Set);
//                        System.out.println("Aftera1Set:=>"+Aftera1Set);
//                        System.out.println("Aftera2Set:=>"+Aftera2Set);
//                        System.out.println("//////////////////////////////////////////");
//                        
                        int candinum1 = TransitionLabel.get(candiacname)+1;
//                        int changecount = 0;
                       
                                     
//                        for(String beforea1:Beforea1Set) {
//                        	System.out.println(".........beforea1:=>"+beforea1);
//                        	for(String aftera2:Aftera2Set) {
//                        		System.out.println(".........aftera2:=>"+aftera2);
                            	if(Beforea1Set.equals(Aftera2Set)) {
                            		//System.out.println("##############################################changecount:=>"+changecount);
                            		                                
                            		for(Transition qian:BeforeTransitionRelation1.keySet()) {
                            			                  
                            			if(qian.getLabel().equals(canditransitionslist.get(a1))||qian.getLabel().equals(canditransitionslist.get(a2))) {
                            				Transition  a3 = new  Transition(qian.getSource(), qian.getTarget(), new Object());
//                            				String newcandiname = candiacname+":"+ candinum1;
                            				String newcandiname = canditransitionslist.get(a1);
                            				a3.setLabel(newcandiname);
                            				noincludeCandiTransitionRelation1.put(a3, BeforeTransitionRelation1.get(qian));
                            				System.out.println("========================");
                            				System.out.println("1noincludeCandiTransitionRelation1:=>"+noincludeCandiTransitionRelation1);
                            				System.out.println("============================");
                            			}
                            		}
                            		                                
                            		                    
                            		for(Transition hou:AfterTransitionRelation1.keySet()) {
                            			System.out.println("hou:=>"+hou.getLabel()+"||a1=>"+a1);
                        				
                            			if(AfterTransitionRelation1.get(hou).getLabel().equals(canditransitionslist.get(a1))||AfterTransitionRelation1.get(hou).getLabel().equals(canditransitionslist.get(a2))) {
                            				Transition  a3qianlabel = new  Transition(hou.getSource(), hou.getTarget(), new Object());
                            				String newcandiname0 = hou.getLabel();
                            				a3qianlabel.setLabel(newcandiname0);
                            				Transition  a3 = new  Transition(AfterTransitionRelation1.get(hou).getSource(), AfterTransitionRelation1.get(hou).getTarget(), new Object());
                            				//String newcandiname = candiacname+":"+ candinum1;
                            				String newcandiname = canditransitionslist.get(a1);
                            				a3.setLabel(newcandiname);
                            				noincludeCandiTransitionRelation1.put(a3qianlabel, a3);
                            				System.out.println("========================");
                            				System.out.println("3noincludeCandiTransitionRelation1:=>"+noincludeCandiTransitionRelation1);
                            				System.out.println("============================");
                            			}

                            		}
                            		canditransitions.remove(canditransitionslist.get(a1));
                            		System.out.println("------------------------->canditransitions0:=>"+canditransitions);
                            		canditransitions.remove(canditransitionslist.get(a2));
                            		System.out.println("------------------------->canditransitions1:=>"+canditransitions);
                            		changenum=1;

                            	}

//                            }
//                        }
//                        System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
//                    	System.out.println("------------a1------------>"+Aftera1Set.size()+"|------------a2------------>"+Aftera2Set.size());
//                    	System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
//                    	for(Transition hou:AfterTransitionRelation1.keySet()) {
//                        	if(canditransitions.contains(canditransitionslist.get(a1))&&canditransitions.contains(canditransitionslist.get(a2))&&Aftera1Set.size()==0&&Aftera2Set.size()==0&&Beforea1Set.size()>0&&Beforea2Set.size()>0&&a1!=a2) {
//                            	System.out.println("-------------4444444%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
//                            	System.out.println("------------a1------------>"+canditransitionslist.get(a1)+"|------------a2------------>"+canditransitionslist.get(a2));
//                            	System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
//                            	Transition  a3qianlabel = new  Transition(hou.getSource(), hou.getTarget(), new Object());
//                				String newcandiname0 = hou.getLabel();
//                				a3qianlabel.setLabel(newcandiname0);
//                            	Transition  a6 = new  Transition(AfterTransitionRelation1.get(hou).getSource(), AfterTransitionRelation1.get(hou).getTarget(), new Object());
//                            	System.out.println("AfterTransitionRelation1.get(hou).getTarget()==\u300b"+AfterTransitionRelation1.get(hou).getTarget()+"|AfterTransitionRelation1.get(hou).getSource()==>"+AfterTransitionRelation1.get(hou).getSource());
//                            	//String newcandiname = candiacname+":"+ candinum1;
//                				String newcandiname = canditransitionslist.get(a1);
//                				a6.setLabel(newcandiname);
//                				System.out.println("a6====?>"+a6.getLabel()+"|AfterTransitionRelation1.get(hou)=>"+AfterTransitionRelation1.get(hou));
//                				noincludeCandiTransitionRelation1.put(a3qianlabel,a6);
//                            	System.out.println("----noincludeCandiTransitionRelation1------------>"+noincludeCandiTransitionRelation1);
//                            	canditransitions.remove(canditransitionslist.get(a1));
//                            	canditransitions.remove(canditransitionslist.get(a2));
//                            	changenum=1;
//                            }
//                    	}


            	      
          			} 
          			      
        		}
          		
     		
          		
        		                               
        		for(Transition keystrans:includeCandiTransitionRelation1.keySet()){
//        			for(String residue:canditransitions){
        				if(canditransitions.contains(keystrans.getLabel())||canditransitions.contains(includeCandiTransitionRelation1.get(keystrans).getLabel())) {
        					Transition  a4 = new  Transition(keystrans.getSource(), keystrans.getTarget(), new Object());
            				String newcandiname = keystrans.getLabel();
            				a4.setLabel(newcandiname);
        					noincludeCandiTransitionRelation1.put(keystrans, includeCandiTransitionRelation1.get(keystrans));
        					System.out.println("------------------------->noincludeCandiTransitionRelation1:=>"+noincludeCandiTransitionRelation1);
        				}

        		}
        		                                                
        		NewTransitionRelation.clear();
        		System.out.println("NewTransitionRelation0:=>"+NewTransitionRelation);
        		NewTransitionRelation.putAll(noincludeCandiTransitionRelation1);
        		System.out.println("NewTransitionRelation1:=>"+NewTransitionRelation);
        		changenum=1;
        		
        		
        		
        		
        		
                                                                                       
         	   
         	   
           	                           
          		HashMap<Transition, Transition> includeCandiTransitionRelation2=new HashMap<Transition, Transition>();
          		HashMap<Transition, Transition> noincludeCandiTransitionRelation2=new HashMap<Transition, Transition>();
          		                                                                             
          		HashSet<String> canditransitions2=new HashSet<String>();

          		System.out.println("*************************************NewTransitionRelation:=>"+NewTransitionRelation);
          		System.out.println("******************NewTransitionRelation.keySet()=>"+NewTransitionRelation.keySet());
          		for(Transition keystrans2:NewTransitionRelation.keySet()){
          			
          			System.out.println("*************************************");
          			System.out.println("candiacname=>"+candiacname+"||keystrans=>"+keystrans2+"||"+NewTransitionRelation.get(keystrans2));
          			System.out.println("*************************************");
          	    	                               
          			System.out.println("keystrans.getLabel()====>"+keystrans2.getLabel());
          			System.out.println("candiacnam====>"+candiacname);
          			System.out.println("keystrans.getLabel().split(\":\")[0]====>"+keystrans2.getLabel().split(":")[0]);
          			System.out.println("keystrans.getLabel()====>"+keystrans2.getLabel());
          	    	if(keystrans2.getLabel().equals(candiacname)||keystrans2.getLabel().split(":")[0].equals(candiacname)) {
          	    		System.out.println("1111111111111111111111111111111111111111111");
          	    		System.out.println("!!TransitionRelation.get(keystrans).getLabel()==>"+NewTransitionRelation.get(keystrans2).getLabel()+"||keystrans.getLabel()=>"+keystrans2.getLabel());
          	    		
          	    		includeCandiTransitionRelation2.put(keystrans2, NewTransitionRelation.get(keystrans2));
          	    		System.out.println("1111includeCandiTransitionRelation2=>"+includeCandiTransitionRelation2);
          	    		canditransitions2.add(keystrans2.getLabel());
          	    		System.out.println("canditransitions==>"+canditransitions2);
          	    		
          	    	}
          	    	else if(NewTransitionRelation.get(keystrans2).getLabel().equals(candiacname)||NewTransitionRelation.get(keystrans2).getLabel().split(":")[0].equals(candiacname)) {
          	    	//	System.out.println("2222222222222222222222222222222222222222222222222222");
          	    		//System.out.println("~~~TransitionRelation.get(keystrans).getLabel()==>"+NewTransitionRelation.get(keystrans2).getLabel()+"||keystrans.getLabel()=>"+keystrans2.getLabel());
          	    		includeCandiTransitionRelation2.put(keystrans2, NewTransitionRelation.get(keystrans2));
          	    	//	System.out.println("222includeCandiTransitionRelation1=>"+includeCandiTransitionRelation2);
          	    		canditransitions2.add(NewTransitionRelation.get(keystrans2).getLabel());
          	    		System.out.println("canditransitions1==>"+canditransitions);
          	    		
          	    	}
          	    	else {
          	    		//System.out.println("33333333333333333333333333333333333333333333");
          	    		noincludeCandiTransitionRelation2.put(keystrans2, NewTransitionRelation.get(keystrans2));
          	    	}
//          	    	  System.out.println("^^^^^000includeCandiTransitionRelation1:=>"+includeCandiTransitionRelation2);
//          	    	    System.out.println("^^^^^^000noincludeCandiTransitionRelation1=>"+noincludeCandiTransitionRelation2);
          	    }
          	    
          	    System.out.println("^^^^^includeCandiTransitionRelation1:=>"+includeCandiTransitionRelation2);
          	    System.out.println("^^^^^^noincludeCandiTransitionRelation1=>"+noincludeCandiTransitionRelation2);
          		
          	
          	                       
          		HashMap<Transition, Transition> BeforeTransitionRelation2=new HashMap<Transition, Transition>();
          		                     
          		HashMap<Transition, Transition> AfterTransitionRelation2=new HashMap<Transition, Transition>();
          		
          		                                                                       
          		for(Transition allkeytrans2:includeCandiTransitionRelation2.keySet()) {
          			//System.out.println("$$$$$allkeytrans.getLabel().replace(\"+complete\", \"\"):=>"+allkeytrans.getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
          			if(allkeytrans2.getLabel().equals(candiacname)||allkeytrans2.getLabel().split(":")[0].equals(candiacname)) {
          				                              
          				BeforeTransitionRelation2.put(allkeytrans2, NewTransitionRelation.get(allkeytrans2));
//          				System.out.println("@@@@@@$$$$$BeforeTransitionRelation:=>"+BeforeTransitionRelation);
          			}
          			//System.out.println("||TransitionRelation.get(allkeytrans).getLabel().replace(\"+complete\", \"\")"+TransitionRelation.get(allkeytrans).getLabel().replace("+complete", "")+"||CANDIAC=>"+candiac);
          			
          			if(NewTransitionRelation.get(allkeytrans2).getLabel().equals(candiacname)||NewTransitionRelation.get(allkeytrans2).getLabel().split(":")[0].equals(candiacname)) {
          				                                 
          				AfterTransitionRelation2.put(allkeytrans2, NewTransitionRelation.get(allkeytrans2));
//          				System.out.println("@@@@@@$$$$$AfterTransitionRelation:=>"+AfterTransitionRelation);
          			}
          			
          		}
          		
//          		@@@@@@$$$$$BeforeTransitionRelation1:=>{A+complete:1=F+complete, A+complete:2=C+complete, A+complete:2=B+complete, A+complete=D+complete}
//                @@@@@@$$$$$AfterTransitionRelation1:=>{X+complete=A+complete:2, D+complete=A+complete:1, B+complete:2=A+complete}
          		System.out.println("@@@@@@$$$$$BeforeTransitionRelation2:=>"+BeforeTransitionRelation2);
          		System.out.println("@@@@@@$$$$$AfterTransitionRelation2:=>"+AfterTransitionRelation2);
          		System.out.println("SIZE2===>"+BeforeTransitionRelation2.size()+"||aftersize==>"+AfterTransitionRelation2.size());
          		       		
        		
      		canditransitions = canditransitions2;
                canditransitionslist = new ArrayList<String>(canditransitions2);
                java.util.Collections.sort(canditransitionslist);
                for (int a1 = 0; a1 < canditransitionslist.size(); a1++) {
  			//System.out.println("a1======>"+a1+":"+canditransitionslist.get(a1)+"|canditransitionslist.size():->"+canditransitionslist.size());
           for (int a2 = canditransitionslist.size() - 1; a2 > a1; a2--) {
        	  // System.out.println("a2======>"+a2+":"+canditransitionslist.get(a2)+"|canditransitionslist.size():->"+canditransitionslist.size());
	   
        	                         
				HashSet<String> Beforea1Set=new HashSet<String>();
				HashSet<String> Aftera1Set=new HashSet<String>();
				HashSet<String> Beforea2Set=new HashSet<String>();
				HashSet<String> Aftera2Set=new HashSet<String>();
				                                                                                                                        
				for(Transition allBefore:AfterTransitionRelation2.keySet()) {
					
					if(Objects.equals(AfterTransitionRelation2.get(allBefore).getLabel(), canditransitionslist.get(a1))) {
						Beforea1Set.add(allBefore.getLabel());
					}
					if(Objects.equals(AfterTransitionRelation2.get(allBefore).getLabel(), canditransitionslist.get(a2))) {
						Beforea2Set.add(allBefore.getLabel());
					}
				}
				                                                                                                                                                
               for(Transition allAfter:BeforeTransitionRelation2.keySet()) {
					if(Objects.equals(allAfter.getLabel(), canditransitionslist.get(a1))) {
						Aftera1Set.add(BeforeTransitionRelation2.get(allAfter).getLabel());
					}
					if(Objects.equals(allAfter.getLabel(), canditransitionslist.get(a2))) {
						Aftera2Set.add(BeforeTransitionRelation2.get(allAfter).getLabel());
					}
				}
               System.out.println("//////////////////////////////////////////");
               System.out.println("newBeforea1Set:=>"+Beforea1Set);
               System.out.println("newBeforea2Set:=>"+Beforea2Set);
               System.out.println("newAftera1Set:=>"+Aftera1Set);
               System.out.println("newAftera2Set:=>"+Aftera2Set);
               System.out.println("//////////////////////////////////////////");
               
//            System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
//           	System.out.println("------------a1------------>"+Aftera1Set.size()+"|------------a2------------>"+Aftera2Set.size());
//           	System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");

                                                                
               	if((canditransitions.contains(canditransitionslist.get(a1))&&canditransitions.contains(canditransitionslist.get(a2))&&Aftera1Set.size()==0&&Aftera2Set.size()==0&&Beforea1Set.size()>0&&Beforea2Set.size()>0)||(canditransitions.contains(canditransitionslist.get(a1))&&canditransitions.contains(canditransitionslist.get(a2))&&Aftera1Set.size()==1&&Aftera2Set.equals(Aftera1Set)&&Beforea1Set.size()>0&&Beforea2Set.size()>0)) {
               		for(Transition hou:AfterTransitionRelation2.keySet()) {
               		System.out.println("-------------4444444%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
                   	System.out.println("------------a1------------>"+canditransitionslist.get(a1)+"|------------a2------------>"+canditransitionslist.get(a2));
                   	System.out.println("-------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%------------");
                	System.out.println("-------------%%hou.getSource()------------"+hou.getSource()+"|hou.getTarget()=>"+hou.getTarget());
                   	if(Objects.equals(AfterTransitionRelation2.get(hou).getLabel(), canditransitionslist.get(a1))||Objects.equals(AfterTransitionRelation2.get(hou).getLabel(), canditransitionslist.get(a2))) {
                   		Transition  a3qianlabel = new  Transition(hou.getSource(), hou.getTarget(), new Object());
           				String newcandiname0 = hou.getLabel();
           				System.out.println("hou.getLabel()=>"+hou.getLabel());
           				a3qianlabel.setLabel(newcandiname0);
                       	Transition  a6 = new  Transition(AfterTransitionRelation2.get(hou).getSource(), AfterTransitionRelation2.get(hou).getTarget(), new Object());
                       	System.out.println("AfterTransitionRelation1.get(hou).getTarget()==\u300b"+AfterTransitionRelation2.get(hou).getTarget()+"|AfterTransitionRelation2.get(hou).getSource()==>"+AfterTransitionRelation2.get(hou).getSource());
                       	//String newcandiname = candiacname+":"+ candinum1;
           				String newcandiname = canditransitionslist.get(a1);
           				a6.setLabel(newcandiname);
           				System.out.println("a6====?>"+a6.getLabel()+"|AfterTransitionRelation1.get(hou)=>"+AfterTransitionRelation2.get(hou));
           				noincludeCandiTransitionRelation2.put(a3qianlabel,a6);
                       	System.out.println("----noincludeCandiTransitionRelation1------------>"+noincludeCandiTransitionRelation2);
                       	canditransitions.remove(canditransitionslist.get(a1));
                       	canditransitions.remove(canditransitionslist.get(a2));
                       	changenum=1;
                   	}
                	if(Aftera1Set.size()==1) {
                		                                               
                		for(Transition before1:BeforeTransitionRelation2.keySet()) {
                			if(Objects.equals(before1.getLabel(), canditransitionslist.get(a1))||Objects.equals(before1.getLabel(), canditransitionslist.get(a2))) {
                				Transition  newb = new  Transition(before1.getSource(), before1.getTarget(), new Object());
//    		    				String newcandiname = candiacname+":"+ candinum1;
    		    				String newcandiname = canditransitionslist.get(a1);
    		    				newb.setLabel(newcandiname);
    		    				noincludeCandiTransitionRelation2.put(newb, BeforeTransitionRelation2.get(before1));
    		    				
                			}
                		}
                	}
                   }
           	}
               	
               	
               	
                                                                              
               	if(canditransitions.size()>2) {
               		System.out.println("\u6ce8\u610fcanditransitionslist.size()>2\uff1a\u4ed6\u662f"+canditransitions);
               	                                     
    				HashSet<String> Beforea1withoutnumberSet=new HashSet<String>();
    				HashSet<String> Aftera1withoutnumberSet=new HashSet<String>();
    				HashSet<String> Beforea2withoutnumberSet=new HashSet<String>();
    				HashSet<String> Aftera2withoutnumberSet=new HashSet<String>();
    				              
    				for(String beforea1:Beforea1Set) {
    					if(beforea1.contains(":")) {
    						Beforea1withoutnumberSet.add(beforea1.split(":")[0]);
    					}	
    					else {
    						Beforea1withoutnumberSet.add(beforea1);
    					}
    				}
    				for(String beforea2:Beforea2Set) {
    					if(beforea2.contains(":")) {
    						Beforea2withoutnumberSet.add(beforea2.split(":")[0]);
    					}	
    					else {
    						Beforea2withoutnumberSet.add(beforea2);
    					}
    				}
    				for(String aftera1:Beforea1Set) {
    					if(aftera1.contains(":")) {
    						Aftera1withoutnumberSet.add(aftera1.split(":")[0]);
    					}	
    					else {
    						Aftera1withoutnumberSet.add(aftera1);
    					}
    				}
    				for(String aftera2:Beforea2Set) {
    					if(aftera2.contains(":")) {
    						Aftera2withoutnumberSet.add(aftera2.split(":")[0]);
    					}	
    					else {
    						Aftera2withoutnumberSet.add(aftera2);
    					}
    				}
    				System.out.println("Beforea1withoutnumberSet:"+Beforea1withoutnumberSet+"|Beforea1Set:"+Beforea1Set);
    				System.out.println("Beforea2withoutnumberSet:"+Beforea2withoutnumberSet+"|Beforea2Set:"+Beforea2Set);
    				System.out.println("Aftera1withoutnumberSet:"+Aftera1withoutnumberSet+"|Aftera1Set:"+Aftera1Set);
    				System.out.println("Aftera2withoutnumberSet:"+Aftera2withoutnumberSet+"|Aftera2Set:"+Aftera2Set);
                   	                                                                
    		    	if(Beforea1withoutnumberSet.equals(Beforea2withoutnumberSet)&&Aftera1withoutnumberSet.equals(Aftera2withoutnumberSet)) {
    		    		                      
    		    		System.out.println("@@@@@@@@"+"canditransitionslist.get(a1)=>"+canditransitionslist.get(a1)+"|canditransitionslist.get(a1):"+canditransitionslist.get(a2));
    		    		for(Transition beforetran:BeforeTransitionRelation2.keySet()) {
    		    			if(beforetran.getLabel().equals(canditransitionslist.get(a1))||beforetran.getLabel().equals(canditransitionslist.get(a2))) {
    		    				Transition  newa = new  Transition(beforetran.getSource(), beforetran.getTarget(), new Object());
//    		    				String newcandiname = candiacname+":"+ candinum1;
    		    				String newcandiname = canditransitionslist.get(a1);
    		    				newa.setLabel(newcandiname);
    		    				noincludeCandiTransitionRelation2.put(newa, BeforeTransitionRelation2.get(beforetran));
    		    				
    		    			}
    		    		}
    		    		                      
    		            for(Transition aftertran:AfterTransitionRelation2.keySet()) {
    		    			if(AfterTransitionRelation2.get(aftertran).getLabel().equals(canditransitionslist.get(a1))||AfterTransitionRelation2.get(aftertran).getLabel().equals(canditransitionslist.get(a2))) {
    		    				Transition  newaqianlabel = new  Transition(aftertran.getSource(), aftertran.getTarget(), new Object());
    		       				String newcandiname0 = aftertran.getLabel();
    		       				System.out.println("hou.getLabel()=>"+aftertran.getLabel());
    		       				newaqianlabel.setLabel(newcandiname0);
    		                   	Transition  newahou = new  Transition(AfterTransitionRelation2.get(aftertran).getSource(), AfterTransitionRelation2.get(aftertran).getTarget(), new Object());
    		                   	System.out.println("AfterTransitionRelation1.get(hou).getTarget()==\u300b"+AfterTransitionRelation2.get(aftertran).getTarget()+"|AfterTransitionRelation2.get(hou).getSource()==>"+AfterTransitionRelation2.get(aftertran).getSource());
    		                   	//String newcandiname = candiacname+":"+ candinum1;
    		       				String newcandiname = canditransitionslist.get(a1);
    		       				newahou.setLabel(newcandiname);
    		       				System.out.println("a6====?>"+newahou.getLabel()+"|AfterTransitionRelation1.get(hou)=>"+AfterTransitionRelation2.get(newahou));
    		       				noincludeCandiTransitionRelation2.put( newaqianlabel,newahou);
    		                   	System.out.println("----noincludeCandiTransitionRelation1------------>"+noincludeCandiTransitionRelation2);
		                   
    		    			}
    		    		}

    		            canditransitions.remove(canditransitionslist.get(a1));
    		           	canditransitions.remove(canditransitionslist.get(a2));
    		        	changenum=1;

               	}   	      
    	}    	
           }
  		}
      	                               
    		for(Transition keystrans2:includeCandiTransitionRelation2.keySet()){
//    			for(String residue:canditransitions){
    				if(canditransitions.contains(keystrans2.getLabel())||canditransitions.contains(includeCandiTransitionRelation2.get(keystrans2).getLabel())) {
    					Transition  a4 = new  Transition(keystrans2.getSource(), keystrans2.getTarget(), new Object());
        				String newcandiname = keystrans2.getLabel();
        				a4.setLabel(newcandiname);
    					noincludeCandiTransitionRelation2.put(keystrans2, includeCandiTransitionRelation2.get(keystrans2));
    					System.out.println("------------------------->noincludeCandiTransitionRelation2:=>"+noincludeCandiTransitionRelation2);
    				}

    		}
    		NewTransitionRelation.clear();
    		System.out.println("NewTransitionRelation0:=>"+NewTransitionRelation);
    		NewTransitionRelation.putAll(noincludeCandiTransitionRelation2);
    		System.out.println("NewTransitionRelation1:=>"+NewTransitionRelation);
    		changenum=1;
        		
          	    	    	}       	
        	                                                      
        	else if(TransitionLabel.get(candiacname)==1){
        		if(changenum==0) {
        			NewTransitionRelation.putAll(TransitionRelation);
        		}
        	}
        }  
		 System.out.println("%%%%%%%%%%%%%NewTransitionRelation=>"+NewTransitionRelation);    	
		 
		 
		 ///////////////////////////////////////////////////////////////////////////////////////////////
		 
		 NewTransitionRelation = ParallelContextRepair.repair(NewTransitionRelation, log);
         ArrayList<String> ActivityLabel=new ArrayList<String>();           
		                                                
	     for(Transition s1:NewTransitionRelation.keySet()) {  
	     	      
	     		String strartString=s1.getLabel();
	     		String endString=NewTransitionRelation.get(s1).getLabel();
	     		 strartString=strartString.replace("+complete", "");
	    		 endString=endString.replace("+complete", "");
	     		ActivityLabel.add(strartString);
	     		ActivityLabel.add(endString);
	     }
//	     for(i=0;i<ActivityLabel.size();i++)
//	     {
//	   	  
//	    	 System.out.println("*********ActivityLabel1.get(i)******"+ActivityLabel.get(i));
//	   	  
//	     }
	                                        
	       ArrayList<String> newActivityLabel = new ArrayList<>();
	       HashSet<String> set = new HashSet<>();
	       set.addAll(ActivityLabel);
	       newActivityLabel.addAll(set);
	       String[] activity11= new  String[newActivityLabel.size()];            
	       for(i=0;i<newActivityLabel.size();i++)
	       {
	          activity11[i]=newActivityLabel.get(i);
	                                                                                                 
	       }
	                                                              
	       DfgMsd dfg=new DfgMsdImpl(activity11);   
	                                                                                                
	       for(i=0;i<activity11.length;i++) {
	            dfg.addActivity(i);
	        }    
	               
	        for(Transition s1:NewTransitionRelation.keySet()) {  
//	        	if(flag==1)
//	        	{  
//	        		String strartString=s1.getLabel();
//	        		String endString=NewTransitionRelation.get(s1).getLabel();
//	                dfg.getDirectlyFollowsGraph().addEdge(newActivityLabel.indexOf(strartString), newActivityLabel.indexOf(endString), 1);	                   
//	        	 }else{
	        		String strartString=s1.getLabel();
	        		String endString=NewTransitionRelation.get(s1).getLabel();	
	        		strartString=strartString.replace("+complete", "");    		
	        		endString=endString.replace("+complete", "");
	        		//System.out.println("edges:"+strartString+" to "+endString+" namely: "+newActivityLabel.indexOf(strartString)+" to "+newActivityLabel.indexOf(endString));
	        		dfg.getDirectlyFollowsGraph().addEdge(newActivityLabel.indexOf(strartString), newActivityLabel.indexOf(endString), 1);
	//        	     dfg.getMinimumSelfDistanceGraph().addEdge(ActivityLabel.indexOf(strartString), ActivityLabel.indexOf(endString), 1);       		       		
	        	//}       	     	
	        }
	                                            
	        MiningParametersIMWithoutLog miningParameters = new MiningParametersIMWithoutLog();
            if (infrequent) {
                dfg = TrialWeightedDfgBuilder.build(log, NewTransitionRelation, transitionClassifier,
                    (java.util.Set<?>) objects[2], (java.util.Set<?>) objects[3]);
                miningParameters = new org.processmining.plugins.inductiveminer2.withoutlog.variants.MiningParametersIMInfrequentWithoutLog();
                miningParameters.setNoiseThreshold(noiseThreshold);
            }
            AcceptingPetriNet APetriNet =InductiveMinerWithoutLogPlugin.minePetriNet(dfg, miningParameters, new Canceller() {
                public boolean isCancelled() { return context.getProgress().isCancelled(); }
            });
	        if (APetriNet == null || context.getProgress().isCancelled()) { return null; }
            Petrinet petrinet1=APetriNet.getNet();
	        /////////////////////////////////////////////////////////////////////////////////////////////
	        
	        
	   
	                                                

			for (org.processmining.models.graphbased.directed.petrinet.elements.Transition transition : petrinet1.getTransitions()) {
                String label = transition.getLabel();
                int suffix = label.lastIndexOf(':');
                if (suffix > 0 && label.substring(suffix + 1).matches("[0-9]+")) {
                    String base = label.substring(0, suffix);
                    if (CandidateActivitySet.contains(base)) { transition.getAttributeMap().put(org.processmining.models.graphbased.AttributeMap.LABEL, base); }
                }
            }
            return APetriNet;
	//        return dfg;
     }
           

    /** Settings fixed to the supplied screenshots; no settings dialog is opened. */
    private static Object[] mineFixedTransitionSystem(PluginContext context, XLog log,
            java.util.Collection<XEventClassifier> classifiers, XEventClassifier transitionClassifier) {
        org.processmining.plugins.transitionsystem.miner.TSMinerInput input =
            new org.processmining.plugins.transitionsystem.miner.TSMinerInput(context, log, classifiers, transitionClassifier);
        input.setUseAttributes(false);
        input.setMaxStates(-1);
        input.setAddArtificialStates(false);
        for (XEventClassifier classifier : classifiers) {
            for (TSDirections direction : TSDirections.values()) {
                TSMinerModirInput settings = input.getModirSettings(direction, classifier);
                settings.setUse(direction == TSDirections.BACKWARD);
                settings.setAbstraction(TSAbstractions.SEQUENCE);
                settings.setHorizon(-1);
                settings.setFilteredHorizon(-1);
                settings.getFilter().clear();
                for (org.deckfour.xes.classification.XEventClass eventClass :
                        input.getLogInfo().getEventClasses(classifier).getClasses()) {
                    settings.getFilter().add(eventClass.getId());
                }
            }
        }
        input.getVisibleFilter().clear();
        for (org.deckfour.xes.classification.XEventClass eventClass :
                input.getLogInfo().getEventClasses(transitionClassifier).getClasses()) {
            input.getVisibleFilter().add(eventClass.getId());
        }
        for (TSConversions conversion : TSConversions.values()) {
            input.getConverterSettings().setUse(conversion, conversion == TSConversions.KILLSELFLOOPS);
        }
        org.processmining.plugins.transitionsystem.miner.TSMinerOutput output = new TSMiner(context).mine(input);
        if (output == null) { return null; }
        return new Object[] {output.getTransitionSystem(), output.getWeights(), output.getStarts(), output.getAccepts()};
    }
    private static final class MiningOptions extends javax.swing.JPanel {
        private static final long serialVersionUID = 1L;
        private final javax.swing.JComboBox<String> mode = new javax.swing.JComboBox<String>(
            new String[] {"No noise filtering (IMw)", "With noise filtering (IMfw)"});
        private final javax.swing.JLabel noiseLabel = new javax.swing.JLabel("Noise threshold");
        private final javax.swing.JSlider noise = new javax.swing.JSlider(0, 1000, 200);
        private final javax.swing.JLabel value = new javax.swing.JLabel("0.20");
        private final javax.swing.JLabel hint = new javax.swing.JLabel("Higher thresholds can remove valid low-frequency behavior.");
        MiningOptions() {
            setLayout(new java.awt.GridBagLayout());
            java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
            c.insets = new java.awt.Insets(8, 8, 8, 8); c.anchor = java.awt.GridBagConstraints.WEST;
            c.gridx=0; c.gridy=0; add(new javax.swing.JLabel("Variant"), c);
            c.gridx=1; c.gridwidth=2; c.fill=java.awt.GridBagConstraints.HORIZONTAL; c.weightx=1; add(mode,c);
            c.gridy=1; c.gridx=0; c.gridwidth=1; c.weightx=0; add(noiseLabel,c);
            noise.setMajorTickSpacing(200); noise.setPaintTicks(true); noise.setPreferredSize(new java.awt.Dimension(360,45));
            c.gridx=1; c.weightx=1; add(noise,c); c.gridx=2; c.weightx=0; add(value,c);
            c.gridx=0; c.gridy=2; c.gridwidth=3; add(hint,c);
            c.gridy=3; add(new javax.swing.JLabel("Transition-system settings use the fixed experimental configuration."),c);
            mode.addActionListener(e -> updateVisibility());
            noise.addChangeListener(e -> value.setText(String.format(java.util.Locale.ROOT,"%.2f",threshold())));
            updateVisibility();
        }
        private void updateVisibility() {
            boolean enabled=withNoise(); noiseLabel.setVisible(enabled); noise.setVisible(enabled);
            noise.setEnabled(enabled); value.setVisible(enabled); hint.setVisible(enabled); revalidate(); repaint();
        }
        boolean withNoise(){return mode.getSelectedIndex()==1;}
        float threshold(){return withNoise()?noise.getValue()/1000.0f:0.0f;}
    }
}
        


final class TrialWeightedDfgBuilder {
 private TrialWeightedDfgBuilder() {}
 private static final class Node {
  final State source, target; final String label;
  Node(Transition t){source=t.getSource();target=t.getTarget();label=t.getLabel();}
  public int hashCode(){return 31*(31*System.identityHashCode(source)+System.identityHashCode(target))+label.hashCode();}
  public boolean equals(Object o){if(!(o instanceof Node))return false;Node n=(Node)o;return source==n.source&&target==n.target&&label.equals(n.label);}
 }
 public static DfgMsd build(XLog original, Map<Transition,Transition> relations, XEventClassifier classifier,
         Set<?> starts, Set<?> ends) {
  Map<Node,Set<Node>> next=new HashMap<Node,Set<Node>>();Set<Node> nodes=new HashSet<Node>();
  for(Map.Entry<Transition,Transition> e:relations.entrySet()){
   Node a=new Node(e.getKey()),b=new Node(e.getValue());nodes.add(a);nodes.add(b);
   if(!next.containsKey(a))next.put(a,new HashSet<Node>());next.get(a).add(b);
  }
  Map<List<String>,List<String>> cache=new HashMap<List<String>,List<String>>();
  XLog renamed=(XLog)original.clone();int traceIndex=0;
  for(XTrace trace:renamed){
   List<String> raw=new ArrayList<String>();for(XEvent event:trace)raw.add(classifier.getClassIdentity(event));
   List<String> labels=cache.get(raw);
   if(labels==null){labels=resolve(raw,nodes,next,starts,ends);cache.put(raw,labels);}
   for(int i=0;i<trace.size();i++)XConceptExtension.instance().assignName(trace.get(i),labels.get(i));traceIndex++;
  }
  MiningParametersIM parameters=new MiningParametersIM();parameters.setClassifier(new XEventNameClassifier());
  DfgMsd dfg=Log2DfgMsd.convert(parameters.getIMLog(renamed));
  System.out.println("Weighted DFG: traces="+traceIndex+", variants="+cache.size()+", starts="+dfg.getStartActivities()+", ends="+dfg.getEndActivities());
  System.out.println("Weighted DFG edges: "+dfg.getDirectlyFollowsGraph());
  return dfg;
 }
 private static List<String> resolve(List<String> raw,Set<Node> nodes,Map<Node,Set<Node>> next,Set<?> starts,Set<?> ends){
  if(raw.isEmpty())return Collections.emptyList();
  Map<Node,Set<List<String>>> paths=new HashMap<Node,Set<List<String>>>();
  for(Node n:nodes)if(starts.contains(n.source.getIdentifier())&&matches(n.label,raw.get(0))){
   Set<List<String>> list=new HashSet<List<String>>();list.add(Collections.singletonList(activity(n.label)));paths.put(n,list);
  }
  for(int i=1;i<raw.size();i++){
   Map<Node,Set<List<String>>> advanced=new HashMap<Node,Set<List<String>>>();
   for(Map.Entry<Node,Set<List<String>>> entry:paths.entrySet())for(Node n:next.getOrDefault(entry.getKey(),Collections.<Node>emptySet())){
    if(!matches(n.label,raw.get(i)))continue;
    if(!advanced.containsKey(n))advanced.put(n,new HashSet<List<String>>());
    for(List<String> prefix:entry.getValue()){
     List<String> labels=new ArrayList<String>(prefix);labels.add(activity(n.label));advanced.get(n).add(labels);
     if(advanced.get(n).size()>2)throw new IllegalStateException("Ambiguous renamed occurrence mapping for "+raw);
    }
   }
   paths=advanced;
  }
  Set<List<String>> complete=new HashSet<List<String>>();
  for(Map.Entry<Node,Set<List<String>>> entry:paths.entrySet())if(ends.contains(entry.getKey().target.getIdentifier()))complete.addAll(entry.getValue());
  if(complete.size()!=1)throw new IllegalStateException("Expected one renamed trace, got "+complete.size()+" for "+raw);
  return complete.iterator().next();
 }
 private static boolean matches(String renamed,String raw){return renamed.equals(raw)||renamed.replaceFirst(":[0-9]+$", "").equals(raw);}
 private static String activity(String label){return label.replace("+complete", "");}
}
