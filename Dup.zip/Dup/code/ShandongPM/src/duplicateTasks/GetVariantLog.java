package duplicateTasks;

/*
 * A fast algorithm to sample log. 
 * The original idea is referred to "The automatic creation of literature abstracts". 
 * 
 * rank a trace by its significance;
 * the significance of a trace is determined by the combination of its activity significance and dfr significance. 
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.deckfour.xes.model.impl.XLogImpl;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.framework.util.ui.widgets.helper.UserCancelledException;

@Plugin(
		name = "Get Varinat Log",// plugin name
		
		returnLabels = {"Sample Log"}, //return labels
		returnTypes = {XLog.class},//return class
		
		//input parameter labels, corresponding with the second parameter of main function
		parameterLabels = {"Large Event Log"},
		
		userAccessible = true,
		help = "This plugin aims to sample an input large-scale example log and returns a small sample log by measuring the significance of traces." 
		)
public class GetVariantLog {
	@UITopiaVariant(
	        affiliation = "TU/e", 
	        author = "Cong liu", 
	        email = "c.liu.3@tue.nl"
	        )
	@PluginVariant(
			variantLabel = "Sampling Big Event Log, default",
			// the number of required parameters, {0} means one input parameter
			requiredParameterLabels = {0}
			)
	public static XLog SimRankSampling(UIPluginContext context, XLog originalLog) throws UserCancelledException
	{	
		double startTime_total=0;
		double endTime_total=0;
		startTime_total=System.currentTimeMillis();
		XLog log1=SimRankSamplingTechnique(originalLog);
		endTime_total=System.currentTimeMillis();

		System.out.println("***************");
		System.out.println("LogRank++ Time:"+(endTime_total-startTime_total));
		System.out.println("***************"); 
		context.log("LogRank++ Time:"+(endTime_total-startTime_total));	
		return log1;
	}
	
	public static XLog SimRankSamplingTechnique(XLog originalLog)
	{
		//create a new log with the same log-level attributes. 
		XLog sampleLog = new XLogImpl(originalLog.getAttributes());
		//keep an ordered list of traces names. 
		ArrayList<String> TraceIdList = new ArrayList<>();
//		****************************************��ù켣����******************************
		HashMap<XTrace,String> compareString=new HashMap<>();
		HashSet<String> compareString1=new HashSet<>();
		for (XTrace trace: originalLog)	{   ///all trace size!=0
			String mergeTransition="";
			for(XEvent event: trace){  
				String transition = event.getAttributes().get("concept:name").toString();       //Resource
				mergeTransition=mergeTransition+transition;
			}
			compareString1.add(mergeTransition);
			compareString.put(trace, mergeTransition);
		}
        //step1:�Թ켣Ƶ�����м���
		HashMap<XTrace,Integer> traceFrequency=new HashMap<>();
		for(XTrace trace1:originalLog)
		{
			int count=0;
			for(XTrace trace2:originalLog)
			{
				if(compareString.get(trace1).equals(compareString.get(trace2))) {
					count++;
				}
			}
			traceFrequency.put(trace1, count);
		}
		//step2-0:��õ�һ���� variant
		for(XTrace trace:originalLog) {
			String m1=compareString.get(trace);
			if(compareString1.contains(m1)) {//hashset
				compareString1.remove(m1);
			}else {
				traceFrequency.remove(trace);//ɾ���켣��ͬ�Ĺ켣
			}
		}
		//traceFrequency�б�����ǹ켣�����Լ�Ƶ��
		/********************************************************************************************/
		Map<XTrace, Integer> map = traceFrequency;
		XLog VariantLog = new XLogImpl(originalLog.getAttributes());
		for(Map.Entry<XTrace, Integer> entry : map.entrySet()){
			VariantLog.add(entry.getKey());
			System.out.println("key = " + entry.getKey() + ", value = " + entry.getValue());
		}
		
		
		//return the sample log. 
		return VariantLog;	
	}
}